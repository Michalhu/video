# 介绍

## 运行环境
`iot video` 测试环境要求:
1. iot video库版本相应的操作系统;
2. CMAKE需要3.5版本以上

## 编译
&emsp;&emsp;在工程目录执行如下脚本完成编译；
`./cmake_build.sh <platform>`(platform是平台编号,可以查看platform.json文件确定)

## 使用方法
&emsp;&emsp;启动 `demo` 的方法；
1. 修改设备端三元组信息;
    将在腾讯云物联网智能视频服务创建的设备的设备三元组（productId、deviceName、deviceSecret）信息填写到device_info.json中或者直接写到SDK初始化参数中，如：

  ```json
  {
      "auth_mode": "KEY",
      "productId": "xxxx",
      "productSecret": "YOUR_PRODUCT_SECRET",
      "deviceName": "xxxxx",
      "key_deviceinfo": {
          "deviceSecret": "xxxxx"
      },
      "cert_deviceinfo": {
          "devCertFile": "YOUR_DEVICE_CERT_FILE_NAME",
          "devPrivateKeyFile": "YOUR_DEVICE_PRIVATE_KEY_FILE_NAME"
      },
      "region": "china"
  }
  ```
2. `iot_video_demo` 和 `iot_video_ipc`根据版本情况选择其中一个启动即可;
- iot_video_demo执行命令: `./iot_video_demo`
- iot_video_ipc执行命令: `./iot_video_ipc`

## 说明
&emsp;&emsp;`samples/CMakeList.txt`中的选项说明:
- `FEATURE_AVT_P2P_ENABLED` 为 `ON`,说明当前版本支持`P2P`裸接口功能;否则`P2P`裸接口已裁剪.
- `FEATURE_ONLY_XP2P_ENABLED`为`ON`,说明当前的版本仅支持`P2P`裸接口, 音视频传输接口已裁剪;否则音视频传输接口和`p2p`裸接口同时支持.
- `FEATURE_USR_COMMAND_ENABLED` 为`ON`,说明当前版本支持自定义信令;否则不支持，相关接口已裁剪.
- `FEATURE_CLOUD_STORAGE_ENABLED` 为`ON`,说明当前版本支持云存储;否则不支持，相关接口已裁剪.
- `FEATURE_CS_AACENC_ENABLED`为`ON`, 说明当前版本云存支持`PCM`和`G771`转码`AAC`,;否则不支持，相关接口已裁剪.
- `FEATURE_CS_USE_HTTPS`为`ON`,说明当前版本云存使用`HTTPS`, 否则使用`HTTP`.
- `FEATURE_CONFIG_NET_ENABLED` 为`ON`,说明当前版本支持配网;否则不支持，相关接口已裁剪.
- `FEATURE_OTA_COMM_ENABLED` 为`ON`,说明当前版本支持OTA;否则不支持，相关接口已裁剪.
- `FEATURE_LOCAL_RECORD_ENABLED` 为`ON`,说明当前版本支持本地录像;否则不支持，相关接口已裁剪.
- 其余选项仅做调试使用, 无特殊需求均不开启; 

## 功能
&emsp;&emsp; `iot_video_demo` 用于展示IoT Video SDK的完整功能，包括在IPC和NVR等场景的音视频传输功能, 输入的数据类型为视频(H264,H265)和音频(AAC,G711,PCM)的裸数据;

&emsp;&emsp; `iot_video_ipc` 用于展示IoT Video SDK在网络摄像头IPC场景的基本功能和接口使用，相比iot_video_demo，代码更加精简，建议从这个sample入手;

## 文件说明

| 名称               | 说明                                                         |
| ------------------ | ------------------------------------------------------------ |
| cmake_build.sh          | 编译脚本                                        |
| doc                     | IOT Video的文档                                        |
| demo_media              | 测试的多媒体文件                                        |
| device_info.json        | 设备三元组信息                                  |
| iot_video_demo          | IOT Video demo可执行文件                        |
| p2p_demo                | P2P demo可执行文件                        |
| include                 | IoT Video的头文件                    |
| lib                     | IoT Video依赖的库文件                    |
| tools                   | 物模型生成脚本                    |
| samples                 | IoT Video的demo代码                    |
| platform.json           | 工具链配置的位置|

## `demo_media`目录说明:
1. `xx.aac, xxx.711*` 是音频测试文件,  AAC格式；`xxx.h264(h265)` 是视频测试文件, H264(H265) 裸流;
2. `p2p_test_file.flv`是p2p_demo的测试文件;
3. pic:目录下是图片，作为事件云存的缩略图素材;
4. event_test_script.txt:是测试事件云存功能的脚本；
5. p2p_test_file.flv: 是专门用于测试p2p_demo的素材;
6. demo_media_cfg.ini: 是视频素材的索引文件,demo会通过demo_media_cfg.ini获取音视频的参数信息和文件位置,通过修改该文件可以调整测试音视频, 注意音视频数据和参数一致, 修改后demo需要重启;
7. 详细信息可以参考文档该目录下的文档 《媒体文件说明.txt》;

注意: `demo_media`文件很大, 一般会单独打包, 如果版本中没有`demo_media`,则需要下载后将其拷贝至当前目录;
