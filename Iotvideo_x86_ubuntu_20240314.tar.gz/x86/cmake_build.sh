#! /bin/bash
SHELL_FOLDER=$(dirname $(readlink -f "$0"))
STDCPP_LIBS_TYPE="SHARED"

# build sdk platform toolchain compiler flag sdk_type
function build_sdk()
{
	rm -rf build
	rm -rf export_sdk
	echo "Build iot video $1 samples"
	mkdir -p build
	cd build
	cmake -DPLATFORM=$1 -DTOOL_CHAIN_PATH=$2 -DCOMPILE_TOOLS=$3 -DCOMPILE_FLAG="$(echo ${@:4})" -DSTDCPP_LIBS_TYPE=${STDCPP_LIBS_TYPE} ..
	make
	cd ..
}

# parse platform.json and build sdk
function parse_json_and_build()
{
    JSON_FILE=${SHELL_FOLDER}/platform.json
    # 1.get platform 2.replace }, to }\n 3.replace space with #
    PLATFORM=$(echo $(cat $JSON_FILE) | sed 's/.*\[\(.*\)\].*/\1/g' | sed 's/},/}\n/g' | sed 's/[[:space:]]/#/g')
    
    if [ $# == 2 ] ; then
		if [ $2 == "static" -o $2 == "shared" ]; then
			STDCPP_LIBS_TYPE=$(echo $2 | tr '[:lower:]' '[:upper:]')
        fi
    fi

    declare -A dict
    dict=([name]="value1" [toolchainPath]="value2" [compiler]="value3" [compileFlag]="value3")
    for i in $PLATFORM
    do
        for key in $(echo ${!dict[*]})
        do
            dict[$key]=$(echo $i |sed  's/#/\ /g' | sed "s/^.*\"$key\": \"\([^\"]*\)\".*$/\1/g")
        done
        if [ $1 == ${dict["name"]} ]; then
            if [ "$(echo ${dict["compiler"]})" == "" ]; then
                build_sdk ${dict["name"]} ${dict["toolchainPath"]} "" ${dict["compileFlag"]}
            else
                build_sdk ${dict["name"]} ${dict["toolchainPath"]} ${dict["compiler"]} ${dict["compileFlag"]}
            fi
            return 0
        fi
    done
    echo "Plaform $1 not found in platform.json!"
}

if [ $1 == "clean" ]; then
    echo "clean build & output all"
    rm -rf build
    rm -rf output
else
    parse_json_and_build $*
    exit
fi
