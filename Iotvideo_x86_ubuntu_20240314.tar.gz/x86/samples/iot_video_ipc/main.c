/*****************************************************************************
 * Copyright (C) 2022 THL A29 Limited, a Tencent company. All rights reserved.
 *
 * Licensed under the MIT License (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://opensource.org/licenses/MIT
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/

#include "iv_config.h"
#include "iv_system.h"
#include "data_model.h"
#include "av_talk.h"
#include "cloud_storage.h"
#include "virtual_ipc_ops.h"

#include "qcloud_iot_export.h"
#include "qcloud_iot_import.h"
#include <signal.h>
#include "getopt.h"

extern int params_p2p_log_level;
extern const char *params_device_info_file;


static char *usage = "./iot_video_demo -d [device_info_file] -p [p2p log level]";
static int _parse_arguments(int argc, char** argv)
{
    char* optstring = "d:p:";
    int   opt;

    while ((opt = getopt(argc, argv, optstring)) != -1) {
        switch (opt) {
        case 'd':
            params_device_info_file = optarg;
            break;
        case 'p':
            params_p2p_log_level = atoi(optarg);
            break;
        default:
            printf("usage:\n%s\n", usage);
            return -1;
        }
    }

    return 0;
}

// Linux平台上利用信号来模拟事件触发和云存上报
// "kill -10 pid" to trigger msg send
static void handle_user_signal(int sig)
{
    if (DEVICE_ONLINE_STATUE != sys_get_status()) {
        printf("device off line");
        return;
    }

    printf("trigger msg send\n");
    iv_msg_send_notice(6, HAL_Timer_current_sec());

#ifdef CLOUD_STORAGE_ENABLED
    printf("trigger cs event test\n");
    //cloud_storage_start_event_test();
#endif
}

static uint32_t process_exit = 0;
static void main_exit(int sig)
{
    printf("vIpcExit by signal:%d\n", sig);
    process_exit = 1;
}

int main(int argc, char **argv)
{
    process_exit = 0;
    signal(SIGTERM, main_exit);
    signal(SIGINT, main_exit);
    signal(SIGUSR1, handle_user_signal);
    _parse_arguments(argc, argv);

    int rc = 0;
    // sys模块和dm模块需要先初始化
    rc = sys_init();
    if (rc < 0) {
        printf("sys_init failed\n");
        return -1;
    }

    rc = dm_init();
    if (rc < 0) {
        sys_exit();
        printf("dm_init failed\n");
        return -1;
    }

    // 初始化音视频P2P模块
#ifdef AVT_P2P_ENABLED
    av_talk_init();
#endif

    // 初始化虚拟IPC，从文件读取音视频数据
#if defined(AVT_P2P_ENABLED) || defined(CLOUD_STORAGE_ENABLED) 
    qcloud_virtual_ipc_init();
#endif

    while (DEVICE_ONLINE_STATUE != sys_get_status()) {
        printf("wait for device online status...\n");
        sleep(1);
    }

    //云存模块及OTA必须上线后才能初始化成功;
#ifdef CLOUD_STORAGE_ENABLED
    cloud_storage_init();
#endif

    while (!process_exit) {
        sleep(1);
    }

#ifdef CLOUD_STORAGE_ENABLED
    cloud_storage_exit();
#endif

#ifdef AVT_P2P_ENABLED
    av_talk_exit();
#endif

#if defined(AVT_P2P_ENABLED) || defined(CLOUD_STORAGE_ENABLED) 
    qcloud_virtual_ipc_exit();
#endif

    dm_exit();
    sys_exit();

    return 0;
}
