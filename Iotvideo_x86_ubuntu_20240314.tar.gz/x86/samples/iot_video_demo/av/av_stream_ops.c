/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 *
 *****************************************************************************/
#include "av_stream_ops.h"

#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <sys/prctl.h>
#include <unistd.h>

#include "file_av_stream.h"
#include "iv_system.h"
#include "qcloud_iot_export.h"

#define MAX_VENC_NUM 3
// video and audio
#define MAX_DEC_NUM 2

typedef struct {
    char running;
    char pause;
    char waiting_key_frame;
    uint32_t visitor;
    FILE *fp_save;
    int status_cnt;
    uint64_t end_time;
} av_visitor_info_s;

typedef struct {
    void *handle;
    char running;
    uint32_t channel;
    iv_avt_video_res_type_e video_res_type;
    av_visitor_info_s visitor_cfg[MAX_CONNECT_NUM];
    int cnt;
} av_enc_handle_s;

typedef struct {
    char running;
    uint32_t channel;
    av_visitor_info_s visitor_cfg[MAX_CONNECT_NUM];
    int cnt;
} av_dec_handle_s;

typedef struct {
    char running;
    uint32_t visitor;
    char *blk_buf;
    int blk_size;
    FILE *fp;
} av_download_info_s;

typedef struct {
    pthread_t pid;
    uint8_t start;
    uint8_t pause;
    uint8_t end;
    av_enc_handle_s enc_handle[MAX_CHANNEL_NUM][MAX_VENC_NUM];
    av_dec_handle_s dec_handle[MAX_CHANNEL_NUM][MAX_DEC_NUM];
    av_download_info_s download_handle[MAX_CHANNEL_NUM][MAX_CONNECT_NUM];
    pthread_mutex_t av_lock;
} av_avt_info_s;

static av_avt_info_s sg_avt_info = {0};

static uint64_t qcloud_get_tick_s(void)
{
    uint64_t time = 0;
    struct timespec on;
    if (clock_gettime(CLOCK_MONOTONIC, &on) == 0) {
        time = on.tv_sec;
    }

    return time;
}

static int qcloud_av_send_cmd_test(int visitor)
{
    static int cnt             = 0;
    char msg_buf[128]          = {0};
    unsigned char rcv_buf[128] = {0};
    size_t recv_len            = sizeof(rcv_buf) - 1;
    snprintf(msg_buf, sizeof(msg_buf), "{\"msg\":\"hellow world %d\"}", cnt);
    iv_avt_send_command(visitor, msg_buf, strlen(msg_buf), rcv_buf, &recv_len, 1000);
    if (recv_len > 0) {
        //此处加上截止符是为了让打印输出完整
        rcv_buf[recv_len] = '\0';
        Log_d("recv len %d data %s", recv_len, rcv_buf);
    }
    cnt++;
    return 0;
}

static void *av_file_stream_proc(void *pParm)
{
    prctl(PR_SET_NAME, "av_file_stream_proc");

    int a_rc                       = 0;
    int v_rc                       = 0;
    int rc                         = 0;
    iv_cm_aenc_stream_s a_stream   = {0};
    iv_cm_aenc_pack_s aenc_packet  = {0};
    iv_cm_venc_stream_s v_stream   = {0};
    iv_cm_venc_pack_s venc_packet  = {0};
    iv_cm_avenc_stream_s av_stream = {0};

    Log_d("av_file_stream_proc thread begin!");
    pthread_detach(pthread_self());
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    p_avt_stream_info->end           = 0;
    while (p_avt_stream_info->start) {
        for (int i = 0; i < MAX_CHANNEL_NUM; i++) {
            for (int j = 0; j < MAX_VENC_NUM; j++) {
                av_enc_handle_s *p_enc_handle = &p_avt_stream_info->enc_handle[i][j];
                pthread_mutex_lock(&p_avt_stream_info->av_lock);
                /*if (!p_enc_handle->running) {
                    usleep(100);
                    continue;
                }*/

                if (!p_enc_handle->handle) {
                    pthread_mutex_unlock(&p_avt_stream_info->av_lock);
                    continue;
                }

                a_rc = qcloud_get_audio_from_file(p_enc_handle->handle, &aenc_packet);
                v_rc = qcloud_get_video_from_file(p_enc_handle->handle, &venc_packet);
                //音频和视频都未获取到
                if ((a_rc < 0) && (v_rc < 0)) {
                    pthread_mutex_unlock(&p_avt_stream_info->av_lock);
                    usleep(1000);
                    continue;
                }

                for (int k = 0; k < MAX_CONNECT_NUM; k++) {
                    if (!p_enc_handle->visitor_cfg[k].running) {
                        continue;
                    }

                    if (p_enc_handle->visitor_cfg[k].pause) {
                        // qcloud_update_base_time(p_enc_handle->handle);
                        // 这句先去掉，否则因为时间戳的原因暂停后seek再播放会失败
                        continue;
                    }

                    uint32_t visitor = p_enc_handle->visitor_cfg[k].visitor;
                    if (p_enc_handle->visitor_cfg[k].end_time) {
                        if (p_enc_handle->visitor_cfg[k].end_time < qcloud_get_tick_s()) {
                            Log_i("send finish stream message");
                            rc = iv_avt_send_finish_stream(visitor, p_enc_handle->channel,
                                                           p_enc_handle->video_res_type);
                            if (rc) {
                                Log_e("send visitor %d channel %d stream %d finish failed %d",
                                      visitor, p_enc_handle->channel, p_enc_handle->video_res_type,
                                      rc);
                            }
                            continue;
                        }
                    }
                    //获取到音频
                    if ((v_rc < 0) && (a_rc == 0)) {
                        a_stream.u32PackCount   = 1;
                        a_stream.pstAencPack[0] = &aenc_packet;
                        rc                      = iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                p_enc_handle->video_res_type,
                                                IV_AVT_STREAM_TYPE_AUDIO, &a_stream);
                        if (rc) {
                            Log_e("visitor %d channel %d stream %d send audio failed %d", visitor,
                                  p_enc_handle->channel, p_enc_handle->video_res_type, rc);
                        }
                    }

                    //获取到视频
                    if ((a_rc < 0) && (v_rc == 0)) {
                        v_stream.u32PackCount   = 1;
                        v_stream.pstVencPack[0] = &venc_packet;
                        rc                      = iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                p_enc_handle->video_res_type,
                                                IV_AVT_STREAM_TYPE_VIDEO, &v_stream);
                        if (rc) {
                            Log_e("visitor %d channel %d stream %d send video failed %d", visitor,
                                  p_enc_handle->channel, p_enc_handle->video_res_type, rc);
                        }
                    }

                    //获取到视频和音频
                    if ((a_rc == 0) && (v_rc == 0)) {
                        a_stream.u32PackCount   = 1;
                        a_stream.pstAencPack[0] = &aenc_packet;
                        v_stream.u32PackCount   = 1;
                        v_stream.pstVencPack[0] = &venc_packet;
                        /*Log_d(
                            "visitor %d chn %d stream %d audio pts %ld and video pts %ld key "
                            "%d",
                            visitor, p_enc_handle->channel, p_enc_handle->video_res_type,
                            aenc_packet.u64PTS, venc_packet.u64PTS, venc_packet.eFrameType);*/
                        //有些播放器对PTS特别敏感，需要严格递增，故在此判断PTS大小;
                        if (aenc_packet.u64PTS > venc_packet.u64PTS) {
                            rc = iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                    p_enc_handle->video_res_type,
                                                    IV_AVT_STREAM_TYPE_VIDEO, &v_stream);
                            rc |= iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                     p_enc_handle->video_res_type,
                                                     IV_AVT_STREAM_TYPE_AUDIO, &a_stream);
                            if (rc) {
                                Log_e("visitor %d channel %d stream %d send av failed %d", visitor,
                                      p_enc_handle->channel, p_enc_handle->video_res_type, rc);
                            }
                        } else {
                            rc = iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                    p_enc_handle->video_res_type,
                                                    IV_AVT_STREAM_TYPE_AUDIO, &a_stream);
                            rc = iv_avt_send_stream(visitor, p_enc_handle->channel,
                                                    p_enc_handle->video_res_type,
                                                    IV_AVT_STREAM_TYPE_VIDEO, &v_stream);
                            if (rc) {
                                Log_e("visitor %d channel %d stream %d send av failed %d", visitor,
                                      p_enc_handle->channel, p_enc_handle->video_res_type, rc);
                            }
                        }
                    }
                    //查询实时传输状态
                    if ((a_rc == 0) || (v_rc == 0)) {
                        if (p_enc_handle->visitor_cfg[k].status_cnt == 200) {
                            // qcloud_av_send_cmd_test(visitor);
                            iv_p2p_send_stats_s stream_send_status  = {0};
                            p_enc_handle->visitor_cfg[k].status_cnt = 0;
                            if (0 == (rc = iv_avt_get_send_stream_status(
                                          visitor, p_enc_handle->channel,
                                          p_enc_handle->video_res_type, &stream_send_status))) {
                                Log_d(
                                    "visitor %d channel %d stream %d transfer inst_net_rate: "
                                    "%u, ave_sent_rate:%u, sum_sent_acked:%llu link_mode %u",
                                    visitor, p_enc_handle->channel, p_enc_handle->video_res_type,
                                    stream_send_status.inst_net_rate,
                                    stream_send_status.ave_sent_rate,
                                    stream_send_status.sum_sent_acked,
                                    stream_send_status.link_mode);
                            }
#ifdef USER_CONGESTION_CTRL
                            size_t size = iv_avt_get_send_stream_buf(visitor, p_enc_handle->channel,
                                                                     p_enc_handle->video_res_type);
                            Log_d("get send stream buf %ld", size);
#endif
                        } else {
                            p_enc_handle->visitor_cfg[k].status_cnt++;
                        }
                    }
                }
                pthread_mutex_unlock(&p_avt_stream_info->av_lock);
            }
        }
        usleep(1000);
    }
    p_avt_stream_info->end = 1;
    Log_d("av_file_stream_proc thread end!");

    return NULL;
}

int qcloud_av_stream_init(void)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;

    if (p_avt_stream_info->start) {
        Log_e("av_file_stream_proc pthread have run, please exit.");
        return -1;
    }

    if (pthread_mutex_init(&p_avt_stream_info->av_lock, NULL)) {
        Log_e("creat mutex failed!");
        return -1;
    }

    p_avt_stream_info->start = 1;
    if (pthread_create(&p_avt_stream_info->pid, NULL, av_file_stream_proc, NULL) < 0) {
        p_avt_stream_info->start = 0;
        Log_e("failed to create the av_file_stream_proc pthread.");
        return -1;
    }

    return 0;
}

int qcloud_av_stream_exit(void)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;

    p_avt_stream_info->start = 0;
    while (!p_avt_stream_info->end) {
        usleep(10000);
    }

    pthread_mutex_destroy(&p_avt_stream_info->av_lock);

    memset(p_avt_stream_info, 0, sizeof(av_avt_info_s));

    return 0;
}

int qcloud_av_enc_start(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type,
                        iv_cm_time_fragment_s *pb_time)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    uint32_t venc_chn                = 0;

    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }
    av_enc_handle_s *p_enc_handle    = &p_avt_stream_info->enc_handle[channel][venc_chn];
    av_visitor_info_s *p_visitor_cfg = p_enc_handle->visitor_cfg;
    int i                            = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_visitor_cfg[i].running && (p_visitor_cfg[i].visitor == visitor)) {
            Log_e("visitor %d channel:%u,venc:%d,has already started!", visitor, channel, venc_chn);
            return -1;
        }
    }

    pthread_mutex_lock(&p_avt_stream_info->av_lock);
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (!p_visitor_cfg[i].running) {
            p_visitor_cfg[i].running           = 1;
            p_visitor_cfg[i].visitor           = visitor;
            p_visitor_cfg[i].waiting_key_frame = 1;
            p_visitor_cfg[i].end_time          = 0;
            if (pb_time) {
                if (pb_time->end_time_s > pb_time->begin_time_s) {
                    p_visitor_cfg[i].end_time =
                        qcloud_get_tick_s() + (pb_time->end_time_s - pb_time->begin_time_s);
                } else {
                    //为了方便演示点播，此处即使时间不对也会发送10s的长度的音视频
                    Log_e("invalid start time %ld and end time %ld", pb_time->begin_time_s,
                          pb_time->end_time_s);
                    p_visitor_cfg[i].end_time = qcloud_get_tick_s() + 10;
                }
            }
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("connect number has already max value!");
        pthread_mutex_unlock(&p_avt_stream_info->av_lock);
        return -1;
    }

    p_enc_handle->cnt++;
    if (p_enc_handle->running) {
        Log_e("channel:%u,venc:%d,has already started!", channel, venc_chn);
        pthread_mutex_unlock(&p_avt_stream_info->av_lock);
        return 0;
    }
    p_enc_handle->handle = qcloud_file_stream_init(channel, venc_chn, 1);
    if (!p_enc_handle->handle) {
        Log_e("channel:%u,venc:%d file stream failed!", channel, venc_chn);
        pthread_mutex_unlock(&p_avt_stream_info->av_lock);
        return -1;
    }

    p_enc_handle->running        = 1;
    p_enc_handle->channel        = channel;
    p_enc_handle->video_res_type = video_res_type;
    pthread_mutex_unlock(&p_avt_stream_info->av_lock);

    Log_d("qcloud_av_enc_start success!");
    return 0;
}

int qcloud_av_enc_pause(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, char pause)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    uint32_t venc_chn                = 0;

    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }
    av_enc_handle_s *p_enc_handle    = &p_avt_stream_info->enc_handle[channel][venc_chn];
    av_visitor_info_s *p_visitor_cfg = p_enc_handle->visitor_cfg;
    p_visitor_cfg[visitor].pause     = pause;

    Log_d("%s stream data!", pause ? "stop" : "resume");
    return 0;
}

int qcloud_av_enc_stop(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    uint32_t venc_chn                = 0;

    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }

    av_enc_handle_s *p_enc_handle    = &p_avt_stream_info->enc_handle[channel][venc_chn];
    av_visitor_info_s *p_visitor_cfg = p_enc_handle->visitor_cfg;
    pthread_mutex_lock(&p_avt_stream_info->av_lock);
    for (int i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_visitor_cfg[i].running && (p_visitor_cfg[i].visitor == visitor)) {
            // p_visitor_cfg[i].running = 0;
            // p_visitor_cfg[i].visitor = 0;
            memset(&p_visitor_cfg[i], 0, sizeof(av_visitor_info_s));
            break;
        }
    }

    if (p_enc_handle->cnt > 0) {
        p_enc_handle->cnt--;
    }

    if ((0 == p_enc_handle->cnt) && (p_enc_handle->handle)) {
        qcloud_file_stream_exit(p_enc_handle->handle);
        p_enc_handle->handle  = NULL;
        p_enc_handle->running = 0;
    }
    pthread_mutex_unlock(&p_avt_stream_info->av_lock);

    Log_d("qcloud_av_enc_stop channel %d stream %d success!", channel, video_res_type);
    return 0;
}

void qcloud_av_enc_get_enc_info(uint32_t channel, iv_avt_video_res_type_e video_res_type,
                                iv_cm_av_data_info_s *pstAvDataInfo)
{
    uint32_t venc_chn = 0;
    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }
    qcloud_get_file_stream_format(channel, venc_chn, pstAvDataInfo);
}

int qcloud_av_dec_start(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type, iv_cm_av_data_info_s *pstAvDataInfo)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    if (channel >= MAX_CHANNEL_NUM || stream_type > IV_AVT_STREAM_TYPE_VIDEO) {
        Log_e("invalid channel %d or type %d!", channel, stream_type);
        return -1;
    }

    av_dec_handle_s *p_dec_handle    = &p_avt_stream_info->dec_handle[channel][stream_type];
    av_visitor_info_s *p_visitor_cfg = p_dec_handle->visitor_cfg;

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_visitor_cfg[i].running && (p_visitor_cfg[i].visitor == visitor)) {
            Log_e("visitor %d channel:%u decode has already started!", visitor, channel);
            return -1;
        }
    }

    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (!p_visitor_cfg[i].running) {
            p_visitor_cfg[i].running = 1;
            p_visitor_cfg[i].visitor = visitor;
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("connect number has already max value!\n");
        return -1;
    }

    char dec_name[64] = {0};
    if (stream_type == IV_AVT_STREAM_TYPE_AUDIO) {
        switch (pstAvDataInfo->eAudioType) {
            case IV_CM_AENC_TYPE_AAC:
                snprintf(dec_name, sizeof(dec_name), "./visitor%d_chn%d_recv_stream.aac", visitor,
                        channel);
                break;
            case IV_CM_AENC_TYPE_G711A:
            case IV_CM_AENC_TYPE_G711U:
                snprintf(dec_name, sizeof(dec_name), "./visitor%d_chn%d_recv_stream.g711", visitor,
                        channel);
                break;
            case IV_CM_AENC_TYPE_PCM:
                snprintf(dec_name, sizeof(dec_name), "./visitor%d_chn%d_recv_stream.pcm", visitor,
                        channel);
                break;
            default:
                Log_e("invalid audio format %d", pstAvDataInfo->eAudioType);
                // return -1;
        }

    } else if (stream_type == IV_AVT_STREAM_TYPE_VIDEO) {
        switch(pstAvDataInfo->eVideoType) {
            case IV_CM_VENC_TYPE_H264:
                snprintf(dec_name, sizeof(dec_name), "./visitor%d_chn%d_recv_stream.h264", visitor,
                        channel);
                break;
            case IV_CM_VENC_TYPE_H265:
                snprintf(dec_name, sizeof(dec_name), "./visitor%d_chn%d_recv_stream.h265", visitor,
                        channel);
                break;
            default:
                Log_e("invalid video format %d", pstAvDataInfo->eVideoType);
        }
    }
    if (strlen(dec_name)) {
        p_visitor_cfg[i].fp_save = fopen(dec_name, "wb");
        if (!p_visitor_cfg[i].fp_save) {
            Log_e("channel:%u open file %s failed!", channel, dec_name);
            return -1;
        }
    }

    p_dec_handle->cnt++;
    if (!p_dec_handle->running) {
        p_dec_handle->channel = channel;
        p_dec_handle->running = 1;
    }

    Log_d("qcloud_av_dec_start success!\n");
    return 0;
}

int qcloud_av_dec_stop(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;

    if (channel >= MAX_CHANNEL_NUM || stream_type > IV_AVT_STREAM_TYPE_VIDEO) {
        Log_e("invalid channel %d or type %d!", channel, stream_type);
        return -1;
    }

    av_dec_handle_s *p_dec_handle    = &p_avt_stream_info->dec_handle[channel][stream_type];
    av_visitor_info_s *p_visitor_cfg = p_dec_handle->visitor_cfg;

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_visitor_cfg[i].running && (p_visitor_cfg[i].visitor == visitor)) {
            p_visitor_cfg[i].running = 0;
            p_visitor_cfg[i].visitor = 0;
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("visitor %d channel:%u decode is invalid or not running!", visitor, channel);
        return -1;
    }

    if (p_visitor_cfg[i].fp_save) {
        Log_d("end of stream %d, close fp_save", stream_type);
        fclose(p_visitor_cfg[i].fp_save);
        p_visitor_cfg[i].fp_save = NULL;
    }

    memset(&p_visitor_cfg[i], 0, sizeof(av_visitor_info_s));

    if (p_dec_handle->cnt > 0) {
        p_dec_handle->cnt--;
    }

    if (0 == p_dec_handle->cnt) {
        p_dec_handle->channel = 0;
        p_dec_handle->running = 0;
    }

    Log_d("qcloud_av_dec_stop success!");

    return 0;
}

int qcloud_av_dec_play(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type,
                       void *pStream)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;

    if (channel >= MAX_CHANNEL_NUM || stream_type > IV_AVT_STREAM_TYPE_VIDEO) {
        Log_e("invalid channel %d or type %d!", channel, stream_type);
        return -1;
    }

    av_dec_handle_s *p_dec_handle    = &p_avt_stream_info->dec_handle[channel][stream_type];
    av_visitor_info_s *p_visitor_cfg = p_dec_handle->visitor_cfg;

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_visitor_cfg[i].running && (p_visitor_cfg[i].visitor == visitor)) {
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("visitor %d channel:%u decode is invalid!", visitor, channel);
        return -1;
    }

    iv_cm_aenc_stream_s *p_a_stream = NULL;
    iv_cm_venc_stream_s *p_v_stream = NULL;
    if (p_dec_handle->running) {
        switch (stream_type) {
            case IV_AVT_STREAM_TYPE_AUDIO:
                p_a_stream = (iv_cm_aenc_stream_s *)pStream;
                if (p_visitor_cfg[i].fp_save) {
                    for (int j = 0; j < p_a_stream->u32PackCount; j++) {
                        fwrite(p_a_stream->pstAencPack[j]->pu8Addr,
                               p_a_stream->pstAencPack[j]->u32Len, 1, p_visitor_cfg[i].fp_save);
                        fflush(p_visitor_cfg[i].fp_save);
                    }
                }
                break;
            case IV_AVT_STREAM_TYPE_VIDEO:
                p_v_stream = (iv_cm_venc_stream_s *)pStream;
                if (p_visitor_cfg[i].fp_save) {
                    for (int j = 0; j < p_v_stream->u32PackCount; j++) {
                        fwrite(p_v_stream->pstVencPack[j]->pu8Addr, 1, p_v_stream->pstVencPack[j]->u32Len, p_visitor_cfg[i].fp_save);
                        fflush(p_visitor_cfg[i].fp_save);
                    }
                }
                break;
            case IV_AVT_STREAM_TYPE_AV:
                Log_e("current iot video version don't support audio and video!");
                break;
            default:
                break;
        }
    } else {
        Log_e("invalid channel %d", channel);
    }

    return 0;
}

int qcloud_av_get_pb_progress(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    uint32_t venc_chn                = 0;

    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }

    return qcloud_get_stream_progress(p_avt_stream_info->enc_handle[channel][venc_chn].handle);
}

int qcloud_av_seek(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, iv_cm_pb_seek_s seek)
{
    av_avt_info_s *p_avt_stream_info = &sg_avt_info;
    uint32_t venc_chn                = 0;

    if (video_res_type == IV_AVT_VIDEO_RES_HD) {
        venc_chn = 2;
    } else if (video_res_type == IV_AVT_VIDEO_RES_SD) {
        venc_chn = 1;
    } else if (video_res_type == IV_AVT_VIDEO_RES_FL) {
        venc_chn = 0;
    }

    return qcloud_file_seek_ms(p_avt_stream_info->enc_handle[channel][venc_chn].handle, seek.seek_time_ms);
}

int qcloud_av_download_start(uint32_t visitor, uint32_t channel, void *args)
{
    iv_cm_download_param_s *p_download_file = (iv_cm_download_param_s *)args;

    if (!args) {
        Log_e("input parameter is NULL!");
        return -1;
    }

    if (channel >= MAX_CHANNEL_NUM) {
        Log_e("invalid channel %d!", channel);
        return -1;
    }

    av_download_info_s *p_download_handle = sg_avt_info.download_handle[channel];

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_download_handle[i].running && (visitor == p_download_handle[i].visitor)) {
            Log_e("visitor %d channel:%u download has already started!", visitor, channel);
            return -1;
        }
    }

    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (!p_download_handle[i].running) {
            p_download_handle[i].running = 1;
            p_download_handle[i].visitor = visitor;
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("connect number has already max value!\n");
        return -1;
    }

    int rc         = 0;
    char path[128] = {0};
    snprintf(path, sizeof(path), "./demo_media/%s", p_download_file->file_name);
    FILE *fp = fopen(path, "rb");
    if (!fp) {
        Log_e("open file %s failed!", path);
        return -1;  //关闭下载
    }
    fseek(fp, p_download_file->file_offset, SEEK_SET);
    p_download_handle[i].blk_size = 1024;
    char *buf                     = malloc(p_download_handle[i].blk_size);
    if (!buf) {
        Log_e("malloc buffer %d failed!", p_download_handle[i].blk_size);
        fclose(fp);
        fp = NULL;
        rc = -1;  //关闭下载
    }

    p_download_handle[i].fp      = fp;
    p_download_handle[i].blk_buf = buf;

    if (rc) {
        qcloud_av_download_stop(visitor, channel);
    }
    return rc;
}

int qcloud_av_download_stop(uint32_t visitor, uint32_t channel)
{
    int rc = 0;

    if (channel >= MAX_CHANNEL_NUM) {
        Log_e("invalid channel %d!", channel);
        return -1;
    }

    av_download_info_s *p_download_handle = sg_avt_info.download_handle[channel];

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_download_handle[i].running && (p_download_handle[i].visitor == visitor)) {
            p_download_handle[i].running = 0;
            p_download_handle[i].visitor = 0;
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("visitor %d channel:%u download is invalid!", visitor, channel);
        return -1;
    }

    if (p_download_handle[i].fp) {
        fclose(p_download_handle[i].fp);
        p_download_handle[i].fp = NULL;
    }

    if (p_download_handle[i].blk_buf) {
        free(p_download_handle[i].blk_buf);
        p_download_handle[i].blk_buf = NULL;
    }

    memset(&p_download_handle[i], 0, sizeof(av_download_info_s));
    return rc;
}

int qcloud_av_download_running(uint32_t visitor, uint32_t channel, void *args)
{
    int rc = 0;

    if (channel >= MAX_CHANNEL_NUM) {
        Log_e("invalid channel %d!", channel);
        return -1;
    }

    iv_cm_memory_s *p_data_buf            = (iv_cm_memory_s *)args;
    av_download_info_s *p_download_handle = sg_avt_info.download_handle[channel];

    int i = 0;
    for (i = 0; i < MAX_CONNECT_NUM; i++) {
        if (p_download_handle[i].running && (p_download_handle[i].visitor == visitor)) {
            break;
        }
    }

    if (i >= MAX_CONNECT_NUM) {
        Log_e("visitor %d channel:%u download is invalid!", visitor, channel);
        return -1;
    }

    if (feof(p_download_handle[i].fp)) {
        p_data_buf->buf         = NULL;
        p_data_buf->size        = -1;
        p_data_buf->buf_free_fn = NULL;
        return -1;
    }

    uint32_t read_len = 0;
    if (p_download_handle[i].fp && p_download_handle[i].blk_buf) {
        read_len = fread(p_download_handle[i].blk_buf, 1, p_download_handle[i].blk_size,
                         p_download_handle[i].fp);
        if (read_len <= 0) {
            Log_e("read frame error!");
            p_data_buf->buf         = NULL;
            p_data_buf->size        = -1;
            p_data_buf->buf_free_fn = NULL;
            return -1;
        }
    }

    p_data_buf->buf         = p_download_handle[i].blk_buf;
    p_data_buf->size        = read_len;
    p_data_buf->buf_free_fn = NULL;

    return rc;
}