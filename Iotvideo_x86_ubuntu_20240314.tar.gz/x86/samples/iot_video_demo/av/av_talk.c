/*
 * Tencent is pleased to support the open source community by making IoT Hub
 available.
 * Copyright (C) 2016 THL A29 Limited, a Tencent company. All rights reserved.

 * Licensed under the MIT License (the "License"); you may not use this file
 except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT

 * Unless required by applicable law or agreed to in writing, software
 distributed under the License is
 * distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND,
 * either express or implied. See the License for the specific language
 governing permissions and
 * limitations under the License.
 *
 */
#include <arpa/inet.h>
#include <net/if.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>

#include "av_stream_ops.h"
#include "iv_av.h"
#include "iv_cm.h"
#include "iv_config.h"
#include "qcloud_iot_export.h"

#define RECV_STREAM_FILE "./recv_audio_data.aac"
static FILE *sg_file_stream = NULL;
static char sg_is_voice     = 0;

void av_buf_free_cb(uint8_t *addr, size_t size)
{
    if (addr) {
        free(addr);
    }
}

static int av_get_file_size(const char *file_name)
{
    int ret  = 0;
    FILE *fp = NULL;
    if (file_name) {
        fp = fopen(file_name, "r");
        if (!fp) {
            Log_e("invalid file path %s", file_name);
            return 0;
        }
        fseek(fp, 0, SEEK_END);
        ret = (int)ftell(fp);
        fclose(fp);
    }
    return ret;
}

void av_talk_get_enc_info(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type,
                          iv_cm_av_data_info_s *p_av_data_info)
{
    Log_i("visitor:%d channel:%d stream %d", visitor, channel, video_res_type);
    qcloud_av_enc_get_enc_info(channel, video_res_type, p_av_data_info);
}

void av_talk_start_real_play(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, void *args)
{
    iv_avt_req_stream_info_s *req_args = (iv_avt_req_stream_info_s *)args;
    if (args) {
        Log_i("recv usr data:%p", args);
        if (req_args->requester) {
            Log_i("stream requester:%s", req_args->requester);
        }
        if (req_args->user_args) {
            Log_i("stream user_args:%p", req_args->user_args);
        }
    }
    Log_i("visitor:%d channel:%d stream %d", visitor, channel, video_res_type);

    if (video_res_type == IV_AVT_VIDEO_RES_PB) {
        iv_cm_time_fragment_s *pb_time = (iv_cm_time_fragment_s *)(req_args->pb_time);
        Log_i("start palyback begin time:%lld and end time %lld", pb_time->begin_time_s, pb_time->end_time_s);
        qcloud_av_enc_start(visitor, channel, video_res_type, pb_time);
    } else {
        qcloud_av_enc_start(visitor, channel, video_res_type, NULL);
    }
}

void av_talk_stop_real_play(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type)
{
    Log_i("visitor %d channel %d stream %d!", visitor, channel, video_res_type);
    if (video_res_type == IV_AVT_VIDEO_RES_PB) {
        qcloud_av_enc_stop(visitor, channel, video_res_type);
    } else {
        qcloud_av_enc_stop(visitor, channel, video_res_type);
    }
}

// 开始收流之后，收到第一个音频帧和第一个视频帧，该回调会被分别调用，即可能被调用两次
int av_talk_start_recv_stream(uint32_t visitor, uint32_t channel, 
    iv_avt_stream_type_e stream_type, iv_cm_av_data_info_s *p_av_data_info)
{
    Log_i("visitor %d channel %d stream %d", visitor, channel, stream_type);
    if (stream_type == IV_AVT_STREAM_TYPE_AUDIO) {
        Log_i("audio: type(%d), mode(%d), bitwidth(%d), sample rate(%d) sample number(%d)", p_av_data_info->eAudioType,
          p_av_data_info->eAudioMode, p_av_data_info->eAudioBitWidth, p_av_data_info->eAudioSampleRate,
          p_av_data_info->u32SampleNumPerFrame);
    } else if (stream_type == IV_AVT_STREAM_TYPE_VIDEO) {
        Log_i("video: type(%d), width(%d), height(%d), sample rate(%d)", p_av_data_info->eVideoType,
          p_av_data_info->u32VideoWidth, p_av_data_info->u32VideoHeight, p_av_data_info->u32Framerate);
    }
    
    qcloud_av_dec_start(visitor, channel, stream_type, p_av_data_info);
    sg_is_voice = 1;

    return 0;
}

// 结束收流的回调只会被调用一次
int av_talk_stop_recv_stream(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type)
{
    Log_i("visitor %d channel %d stream %d ", visitor, channel, stream_type);

    if (stream_type == IV_AVT_STREAM_TYPE_AV) {
        qcloud_av_dec_stop(visitor, channel, IV_AVT_STREAM_TYPE_AUDIO);
        qcloud_av_dec_stop(visitor, channel, IV_AVT_STREAM_TYPE_VIDEO);
    } else {
        qcloud_av_dec_stop(visitor, channel, stream_type);
    }

    sg_is_voice = 0;
    return 0;
}

int av_talk_recv_stream(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type, void *pStream)
{
    return qcloud_av_dec_play(visitor, channel, stream_type, pStream);
}

void buf_free_fn_cb(uint8_t *addr, size_t size)
{
    if (addr) {
        free(addr);
    }
}

void av_talk_recv_user_data(uint32_t visitor, uint32_t channel, const char *src, uint32_t src_len, iv_cm_memory_s *dst)
{
    Log_i("visitor %d channel %d recv char = %p length = %hu\n", visitor, channel, src, src_len);
    char *val                   = "IoT Video Device C SDK";
    char recv_usr_data_name[64] = {0};
    dst->buf                    = (char *)malloc(strlen(val) + 1);

    if (dst->buf) {
        memcpy(dst->buf, val, (strlen(val) + 1));
        dst->size        = strlen(val) + 1;
        dst->buf_free_fn = buf_free_fn_cb;
    }

    snprintf(recv_usr_data_name, 64, "./visitor%d_chn%d_recv_cmd.txt", visitor, channel);

    if (src_len < 64) {
        Log_d("command:\n%s\n", src);
    } else {
        FILE *save_file = fopen(recv_usr_data_name, "w");
        fwrite(src, 1, src_len, save_file);
        fclose(save_file);
    }
}

void av_talk_notify_process(iv_avt_event_e event, uint32_t visitor, uint32_t channel,
                            iv_avt_video_res_type_e video_res_type)
{
    if (IV_AVT_EVENT_P2P_PEER_READY == event) {
        Log_d("avt p2p is ready");
    }
    Log_i("visitor %d channel %d stream %d event id %d", visitor, channel, video_res_type, event);
}

int av_talk_get_dev_name_proc(uint32_t visitor, uint32_t channel, iv_cm_memory_s *dev_name, uint8_t *is_online)
{
    Log_i("visitor %d channel %d", visitor, channel);
    dev_name->buf = malloc(32);
    if (!dev_name->buf) {
        Log_e("malloc buffer failed!");
        return -1;
    }
    dev_name->size        = 32;
    dev_name->buf_free_fn = av_buf_free_cb;
    snprintf(dev_name->buf, 32, "test_ipc%d", channel);
    *is_online = 1;

    return 0;
}

static void av_free(void *ptr)
{
    if (ptr) {
        free(ptr);
    }
}

#ifdef AVT_LAN_ENABLED
static int get_local_ip(char *address, const char *eth_name)
{
    int inet_sock;
    struct ifreq ifr;
    char ip[32] = {0};

    if (eth_name) {
        inet_sock = socket(AF_INET, SOCK_DGRAM, 0);
        strcpy(ifr.ifr_name, eth_name);
        ioctl(inet_sock, SIOCGIFADDR, &ifr);
        strcpy(ip, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr));
        strcpy(address, ip);
        close(inet_sock);
    }
    Log_i("local address %s", ip);
    return 0;
}
#endif

int av_talk_command_proc(iv_avt_command_type_e command, uint32_t visitor, uint32_t channel,
                         iv_avt_video_res_type_e video_res_type, void *args)
{
    Log_d("command %d visitor %d channel %d stream %d args %p", command, visitor, channel, video_res_type, args);
    int rc         = 0;
    char path[128] = {0};

    switch (command) {
        case IV_AVT_COMMAND_USR_DATA: {
            iv_avt_usr_data_parm_s *usr_data = (iv_avt_usr_data_parm_s *)args;
            av_talk_recv_user_data(visitor, channel, usr_data->src, usr_data->src_len, &usr_data->dst);
            break;
        }

        case IV_AVT_COMMAND_REQ_STREAM: {
            iv_avt_req_stream_param_s *req_param = (iv_avt_req_stream_param_s *)args;
            if (IV_AVT_REQUEST_SEND_STREAM == req_param->request_type) {  //直播
                req_param->request_result = IV_AVT_DEV_ACCEPT;
            } else {  //对讲
                req_param->request_result = sg_is_voice ? IV_AVT_DEV_REFUSE : IV_AVT_DEV_ACCEPT;
            }
            break;
        }

        case IV_AVT_COMMAND_CHN_NAME: {
            iv_avt_chn_name_param_s *chn_name = (iv_avt_chn_name_param_s *)args;
            rc = av_talk_get_dev_name_proc(visitor, channel, &chn_name->name, &chn_name->is_online);
            break;
        }

        case IV_AVT_COMMAND_REQ_IFRAME: {
            Log_d("visitor need idr frame!");
            break;
        }

        case IV_AVT_COMMAND_PLAYBACK_PAUSE: {
            qcloud_av_enc_pause(visitor, channel, video_res_type, 1);
            Log_d("playback pause!");
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_RESUME: {
            qcloud_av_enc_pause(visitor, channel, video_res_type, 0);
            Log_d("playback resume!");
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_QUERY_MONTH: {
            iv_cm_query_rd_by_month_s *rd_month = (iv_cm_query_rd_by_month_s *)args;
            rd_month->day                       = 1;
            Log_d("query month year:%d, month:%d, day:%d", rd_month->year, rd_month->month, rd_month->day);
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_QUERY_DAY: {
            iv_cm_query_rd_by_day_s *rd_day = (iv_cm_query_rd_by_day_s *)args;
            Log_d("query day start:%lld, end:%lld, type:%d", rd_day->time_fragment.begin_time_s,
                  rd_day->time_fragment.end_time_s, rd_day->time_fragment.type);
            rd_day->rd_array = (iv_cm_pb_list_s *)malloc(sizeof(iv_cm_pb_list_s) + 5 * sizeof(iv_cm_time_fragment_s));
            if (!rd_day->rd_array) {
                Log_e("malloc failed!");
                return -1;
            }
            rd_day->free_fn                          = av_free;
            rd_day->rd_array->count                  = 5;
            iv_cm_time_fragment_s vir_video_index[5] = {{0, 1633060800, 1633060920},  /*2021-10-01 12:00:00-12:02:00*/
                                                        {0, 1633061000, 1633061120},  /*2021-10-01 12:03:20-12:05:20*/
                                                        {0, 1633061200, 1633061320},  /*2021-10-01 12:06:40-12:08:40*/
                                                        {0, 1633061400, 1633061520},  /*2021-10-01 12:10:00-12:12:00*/
                                                        {0, 1633061600, 1633061720}}; /*2021-10-01 12:13:20-12:15:20*/
            for (int i = 0; i < 5; i++) {
                rd_day->rd_array->file_list[i].type         = vir_video_index[i].type;
                rd_day->rd_array->file_list[i].begin_time_s = vir_video_index[i].begin_time_s;
                rd_day->rd_array->file_list[i].end_time_s   = vir_video_index[i].end_time_s;
            }
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_SEEK: {
            iv_cm_pb_seek_s *pb_seek = (iv_cm_pb_seek_s *)args;
            Log_d("playback seek time:%ld", pb_seek->seek_time_ms);
            rc = qcloud_av_seek(visitor, channel, video_res_type, *pb_seek);
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_FF: {
            iv_cm_pb_ff_s *pb_ff = (iv_cm_pb_ff_s *)args;
            Log_d("playback fast forward:%d", pb_ff->speed);
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_SPEED: {
            iv_cm_pb_speed_s *pb_speed = (iv_cm_pb_speed_s *)args;
            Log_d("playback speed time_ms:%d", pb_speed->time_ms);
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_REWIND: {
            iv_cm_pb_rewind_s *pb_rewind = (iv_cm_pb_rewind_s *)args;
            Log_d("playback rewind begin time:%lld and end time:%lld", pb_rewind->begin_time_s, pb_rewind->end_time_s);
            break;
        }
        case IV_AVT_COMMAND_PLAYBACK_PROGRESS: {
            int *progress_time = (int *)args;
            *progress_time     = qcloud_av_get_pb_progress(visitor, channel, video_res_type);
            break;
        }
        case IV_AVT_COMMAND_QUERY_FILE_LIST: {
            iv_cm_query_file_list_s *p_file_list = (iv_cm_query_file_list_s *)args;
            Log_d("query file time begin:%" PRIu64 ", end:%" PRIu64, p_file_list->time_fragment.begin_time_s,
                  p_file_list->time_fragment.end_time_s);
            p_file_list->file_array =
                (iv_cm_file_list_s *)malloc(sizeof(iv_cm_file_list_s) + 2 * sizeof(iv_cm_file_info_s));
            if (!p_file_list->file_array) {
                Log_e("malloc failed!");
                return -1;
            }
            memset(p_file_list->file_array, 0, sizeof(iv_cm_file_list_s) + 2 * sizeof(iv_cm_file_info_s));
            char *extra_info                    = "{\"key1\":0, \"key2\":\"value2\"}";
            p_file_list->free_fn                = av_free;
            p_file_list->file_array->count      = 2;
            iv_cm_file_info_s vir_file_index[2] = {{IV_CM_FILE_TYPE_VIDEO,
                                                    "p2p_test_file.flv",
                                                    0,
                                                    1633060850,
                                                    1633060880,
                                                    {NULL}}, /*2021-10-01 12:00:00-12:00:30*/
                                                   {IV_CM_FILE_TYPE_PIC,
                                                    "pic/01.jpg",
                                                    0,
                                                    1633061080,
                                                    1633061080,
                                                    {NULL}}}; /*2021-10-01 12:04:40-12:05:10*/

            for (int i = 0; i < p_file_list->file_array->count; i++) {
                memset(path, 0, sizeof(path));
                snprintf(path, sizeof(path), "./demo_media/%s", vir_file_index[i].file_name);
                p_file_list->file_array->file_list[i].file_type = vir_file_index[i].file_type;
                strncpy(p_file_list->file_array->file_list[i].file_name, vir_file_index[i].file_name,
                        sizeof(p_file_list->file_array->file_list[i].file_name));
                p_file_list->file_array->file_list[i].file_size              = av_get_file_size(path);
                p_file_list->file_array->file_list[i].begin_time_s           = vir_file_index[i].begin_time_s;
                p_file_list->file_array->file_list[i].end_time_s             = vir_file_index[i].end_time_s;
                p_file_list->file_array->file_list[i].extra_info.buf         = extra_info;
                p_file_list->file_array->file_list[i].extra_info.size        = strlen(extra_info);
                p_file_list->file_array->file_list[i].extra_info.buf_free_fn = NULL;
            }
            break;
        }
        case IV_AVT_COMMAND_CALL_ANSWER: {
            Log_i("receive command: call answer");
            break;
        }
        case IV_AVT_COMMAND_CALL_HANG_UP: {
            Log_i("receive command: call hang up");
            break;
        }
        case IV_AVT_COMMAND_CALL_REJECT: {
            Log_i("receive command: call reject");
            break;
        }
        case IV_AVT_COMMAND_CALL_CANCEL: {
            Log_i("receive command: call cancel");
            break;
        }
        case IV_AVT_COMMAND_CALL_BUSY: {
            Log_i("receive command: call busy");
            break;
        }
        case IV_AVT_COMMAND_CALL_TIMEOUT: {
            Log_i("receive command: call timeout");
            break;
        }

        default:
            break;
    }

    return rc;
}

int av_talk_download_proc(iv_avt_download_status_e status, uint32_t visitor, uint32_t channel, void *args)
{
    int rc = 0;

    switch (status) {
        case IV_AVT_DOWNLOAD_STATUS_START:
            Log_d("download  status %d visitor %d channel %d  args %p", status, visitor, channel, args);
            rc = qcloud_av_download_start(visitor, channel, args);
            break;
        case IV_AVT_DOWNLOAD_STATUS_RUNNING:
            rc = qcloud_av_download_running(visitor, channel, args);
            break;
        case IV_AVT_DOWNLOAD_STATUS_STOP:
            Log_d("download  status %d visitor %d channel %d  args %p", status, visitor, channel, args);
            rc = qcloud_av_download_stop(visitor, channel);
            break;
        default:
            rc = -1;
            break;
    }
    return rc;
}

void av_talk_get_peer_outer_netinfo(uint32_t visitor, uint32_t channel, char *net_info)
{
    Log_i("visitor is:%d, channel is:%d, peer outerip is: %s", visitor, channel, net_info);
}

int params_p2p_log_level          = IV_AVT_P2P_LOG_INFO;
const char *params_p2p_log_path   = "/tmp";
int params_p2p_protocol           = IV_AVT_P2P_UDP;
int params_p2p_sender_interval_ms = 10;
const char *params_netif_name     = "eth";
char params_proxy_addr[32]        = {0};
int params_p2p_prioriry           = 0;

int av_talk_init(void)
{
    int ret = 0;

    iv_avt_init_parm_s stAvtInitParameters;
    memset(&stAvtInitParameters, 0, sizeof(iv_avt_init_parm_s));
    stAvtInitParameters.max_frame_size    = 384;              // 384kB
    stAvtInitParameters.max_connect_num   = MAX_CONNECT_NUM;  //
    stAvtInitParameters.congestion.enable = true;
#ifdef USER_CONGESTION_CTRL
    stAvtInitParameters.congestion.low_mark  = 0;
    stAvtInitParameters.congestion.warn_mark = 0;
    stAvtInitParameters.congestion.high_mark = 0;
#else
    stAvtInitParameters.congestion.low_mark  = 200 * 1024;
    stAvtInitParameters.congestion.warn_mark = 400 * 1024;
    stAvtInitParameters.congestion.high_mark = 500 * 1024;
#endif

    stAvtInitParameters.p2p_keep_alive.time_inter_s        = 0;
    stAvtInitParameters.p2p_keep_alive.max_attempt_num     = 0;
    stAvtInitParameters.iv_avt_get_av_enc_info_cb          = av_talk_get_enc_info;
    stAvtInitParameters.iv_avt_start_real_play_cb          = av_talk_start_real_play;
    stAvtInitParameters.iv_avt_stop_real_play_cb           = av_talk_stop_real_play;
    stAvtInitParameters.iv_avt_start_recv_stream_cb        = av_talk_start_recv_stream;
    stAvtInitParameters.iv_avt_recv_stream_cb              = av_talk_recv_stream;
    stAvtInitParameters.iv_avt_stop_recv_stream_cb         = av_talk_stop_recv_stream;
    stAvtInitParameters.iv_avt_notify_cb                   = av_talk_notify_process;
    stAvtInitParameters.iv_avt_recv_command_cb             = av_talk_command_proc;
    stAvtInitParameters.iv_avt_download_file_cb            = av_talk_download_proc;
    stAvtInitParameters.iv_avt_get_peer_outer_net_cb   = av_talk_get_peer_outer_netinfo;
    stAvtInitParameters.p2p_init_params.log_level          = params_p2p_log_level;
    stAvtInitParameters.p2p_init_params.log_file_path      = params_p2p_log_path;
    stAvtInitParameters.p2p_init_params.log_file_size      = 1 * 1024 * 1024;
    stAvtInitParameters.p2p_init_params.sender_interval_ms = params_p2p_sender_interval_ms;
    if (strlen(params_proxy_addr)) {
        char *proxy_port = params_proxy_addr;
        Log_d("avt p2p use proxy mode with %s", params_proxy_addr);
        stAvtInitParameters.p2p_init_params.proxy_ip   = strsep(&proxy_port, ":");
        stAvtInitParameters.p2p_init_params.proxy_port = atoi(proxy_port);
        // proxy mode only use UDP protocol
        params_p2p_protocol = IV_AVT_P2P_UDP;
        if (params_p2p_prioriry > 0) {
            stAvtInitParameters.p2p_init_params.thread_policy   = 1; // SCHED_FIFO
            stAvtInitParameters.p2p_init_params.thread_priority = params_p2p_prioriry;
        }        
    }
    // stAvtInitParameters.p2p_init_params.protocol       = params_p2p_protocol;

    // Log_d("avt use protocal :%s", params_p2p_protocol ? "TCP" : "UDP");

#ifdef AVT_LAN_ENABLED
    stAvtInitParameters.net_info.probe_port = 3072;
    stAvtInitParameters.net_info.trans_port = 34567;
    stAvtInitParameters.net_info.vendor_id  = NULL;  // use productid
    stAvtInitParameters.net_info.device_id  = NULL;  // use device name
    get_local_ip(stAvtInitParameters.net_info.local_addr, params_netif_name);
#endif

    ret = iv_avt_init(&stAvtInitParameters);
    if (ret < 0) {
        Log_e("iv_avt_init error:%d", ret);
        return ret;
    }

    ret = qcloud_av_stream_init();
    if (ret < 0) {
        Log_e("qcloud_av_stream_init error:%d", ret);
        return ret;
    }
    sg_is_voice = 0;

    return ret;
}

int av_talk_exit(void)
{
    iv_avt_exit();
    qcloud_av_stream_exit();
    return 0;
}
