/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 *
 *****************************************************************************/

#ifndef __AV_STREAM_OPS_H__
#define __AV_STREAM_OPS_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <stdint.h>

#include "iv_av.h"

#define MAX_CONNECT_NUM 4
//#define USER_CONGESTION_CTRL
/**
 * @brief AV stream initial
 *
 * @return int
 */
int qcloud_av_stream_init(void);

/**
 * @brief AV stream exit
 *
 * @return int
 */
int qcloud_av_stream_exit(void);

/**
 * @brief
 *
 * @param channel
 * @param video_res_type
 * @return int
 */
int qcloud_av_enc_start(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, iv_cm_time_fragment_s *pb_time);

/**
 * @brief
 *
 * @param channel
 * @param video_res_type
 * @return int
 */
int qcloud_av_enc_stop(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type);

/**
 * @brief
 *
 * @param channel
 * @param video_res_type
 * @param p_av_data_info
 */
void qcloud_av_enc_get_enc_info(uint32_t channel, iv_avt_video_res_type_e video_res_type,
                                iv_cm_av_data_info_s *p_av_data_info);

/**
 * @brief
 *
 * @param channel
 * @param p_av_data_info
 * @return int
 */
int qcloud_av_dec_start(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e eStreamType, iv_cm_av_data_info_s *p_av_data_info);

/**
 * @brief
 *
 * @param channel
 * @return int
 */
int qcloud_av_dec_stop(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e stream_type);

/**
 * @brief
 *
 * @param channel
 * @param eStreamType
 * @param pStream
 * @return int
 */
int qcloud_av_dec_play(uint32_t visitor, uint32_t channel, iv_avt_stream_type_e eStreamType,
                       void *pStream);

/**
 * @brief start download function
 *
 * @param visitor
 * @param channel
 * @param args
 * @return int
 */
int qcloud_av_download_start(uint32_t visitor, uint32_t channel, void *args);

/**
 * @brief stop download function
 *
 * @param visitor
 * @param channel
 * @return int
 */
int qcloud_av_download_stop(uint32_t visitor, uint32_t channel);

/**
 * @brief running download function
 *
 * @param visitor
 * @param channel
 * @param args
 * @return int
 */
int qcloud_av_download_running(uint32_t visitor, uint32_t channel, void *args);

int qcloud_av_enc_pause(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, char pause);

int qcloud_av_get_pb_progress(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type);

int qcloud_av_seek(uint32_t visitor, uint32_t channel, iv_avt_video_res_type_e video_res_type, iv_cm_pb_seek_s seek);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __AV_TALK_H__ */