/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 * @file    config.h
 * @brief   Description config function
 * @version v1.0.0
 *
 *****************************************************************************/

#include "ini_config.h"

#include <stdio.h>
#include <string.h>

#include "iniparser.h"
#include "qcloud_iot_export_log.h"

static dictionary* sg_ini = NULL;

int iv_config_init(const char* file_path)
{
    if (access(file_path, F_OK) != 0) {
        Log_w("config file not exit,restore to default!\n");
        return -1;
    }

    sg_ini = iniparser_load(file_path);
    if (sg_ini == NULL) {
        Log_e("iniparser_load file '%s' error!\n", file_path);
        return -1;
    }

    Log_i("load %s ok!", file_path);

    return 0;

error:
    iniparser_freedict(sg_ini);

    return -1;
}

void iv_config_deinit(void)
{
    if (sg_ini) {
        iniparser_freedict(sg_ini);
        sg_ini = NULL;
    }
}

#define VIDEO_HEAD_FLAG(x) "chn%d_video_stream%d:" #x
#define AUDIO_HEAD_FLAG(x) "chn%d_audio:" #x

int iv_config_get_av_param(uint32_t channel, uint32_t stream, iv_cm_av_data_info_s* av_cfg)
{
    int offset        = 0;
    char key[128]     = {0};
    dictionary* p_ini = sg_ini;

    if (!(av_cfg && p_ini)) {
        Log_e("parameter is NULL!");
        return -1;
    }
    // video
    snprintf(key, sizeof(key), VIDEO_HEAD_FLAG(venc_type), channel, stream);
    av_cfg->eVideoType = iniparser_getint(p_ini, key, IV_CM_VENC_TYPE_H264);
    snprintf(key, sizeof(key), VIDEO_HEAD_FLAG(framerate), channel, stream);
    av_cfg->u32Framerate = iniparser_getint(p_ini, key, 25);
    snprintf(key, sizeof(key), VIDEO_HEAD_FLAG(width), channel, stream);
    av_cfg->u32VideoWidth = iniparser_getint(p_ini, key, 640);
    snprintf(key, sizeof(key), VIDEO_HEAD_FLAG(height), channel, stream);
    av_cfg->u32VideoHeight = iniparser_getint(p_ini, key, 480);
    // audio
    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(aenc_type), channel);
    av_cfg->eAudioType = iniparser_getint(p_ini, key, 4);
    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(aenc_mode), channel);
    av_cfg->eAudioMode = iniparser_getint(p_ini, key, 0);
    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(aenc_bit_width), channel);
    av_cfg->eAudioBitWidth = iniparser_getint(p_ini, key, 0);
    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(aenc_sample_rate), channel);
    av_cfg->eAudioSampleRate = iniparser_getint(p_ini, key, 8000);
    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(aenc_sample_num_per_frame), channel);
    av_cfg->u32SampleNumPerFrame = iniparser_getint(p_ini, key, 1024);

    return 0;
}

const char* iv_config_get_video_file_path(uint32_t channel, uint32_t stream)
{
    char key[128]     = {0};
    dictionary* p_ini = sg_ini;

    if (!p_ini) {
        Log_e("parameter is NULL!");
        return NULL;
    }

    snprintf(key, sizeof(key), VIDEO_HEAD_FLAG(file), channel, stream);

    return iniparser_getstring(p_ini, key, NULL);
}

const char* iv_config_get_audio_file_path(uint32_t channel, uint32_t stream)
{
    char key[128]     = {0};
    dictionary* p_ini = sg_ini;

    if (!p_ini) {
        Log_e("parameter is NULL!");
        return NULL;
    }

    snprintf(key, sizeof(key), AUDIO_HEAD_FLAG(file), channel);
    return iniparser_getstring(p_ini, key, NULL);
}