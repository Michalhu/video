#ifndef _FILE_AV_STREAM_H_
#define _FILE_AV_STREAM_H_

#if defined(__cplusplus)
extern "C" {
#endif

#include <sys/time.h>

#include "iv_cm.h"

int qcloud_get_file_stream_format(uint32_t channel, uint32_t stream_type,
                                  iv_cm_av_data_info_s *av_format);

void *qcloud_file_stream_init(uint32_t channel, uint32_t stream_type, uint8_t is_timer);

void qcloud_file_stream_exit(void *handle);

int qcloud_get_audio_from_file(void *handle, iv_cm_aenc_pack_s *aenc_packet);

int qcloud_get_video_from_file(void *handle, iv_cm_venc_pack_s *venc_packet);

int qcloud_update_base_time(void *handle);

int qcloud_get_stream_progress(void *handle);

int qcloud_file_seek_ms(void *handle, uint64_t seek_ms);

#if defined(__cplusplus)
}
#endif

#endif /* _AV_STREAM_PROVIDE_H_ */