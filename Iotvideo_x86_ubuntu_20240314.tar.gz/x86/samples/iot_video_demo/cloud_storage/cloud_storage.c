/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 * @file    cloud_storage.c
 * @brief   Description cloud storage function
 * @version v1.0.0
 *
 *****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/time.h>
#include <time.h>

#include "file_av_stream.h"
#include "iv_av.h"
#include "iv_cs.h"
#include "iv_sys.h"
#include "iv_system.h"
#include "qcloud_iot_export.h"

typedef struct {
    pthread_t pid;
    uint8_t start;
    uint8_t running;
    uint8_t end;
} iv_cs_thread_s;

typedef struct {
    void *handle;
    uint8_t channel;
    uint32_t running;
    iv_avt_video_res_type_e video_res_type;
} cs_enc_info;

typedef struct {
    iv_cs_thread_s event_thread;
    iv_cs_thread_s stream_thread;
    cs_enc_info chl_enc_info[CS_CH_NUM];
} iv_cs_info_s;

static iv_cs_info_s sg_cs_info_handle = {0};

void utc_to_localtime_ms(int64_t time_ms, char *time_buf, int buf_len)
{
    struct tm ltime;
    time_t time_sec = time_ms / 1000;
    localtime_r(&time_sec, &ltime);
    snprintf(time_buf, buf_len, "%04d%02d%02d %02d:%02d:%02d:%03d", ltime.tm_year + 1900,
             ltime.tm_mon + 1, ltime.tm_mday, ltime.tm_hour, ltime.tm_min, ltime.tm_sec,
             (int)(time_ms % 1000));
}

#define CS_FLIE_CHANNEL_ID 0
#define CS_FLIE_STREAM_ID  1

#define EVENT_PIC_PATH        "./demo_media/pic/"
#define EVENT_TSET_FILE       "./demo_media/event_test_script.txt"
#define STR_N_CMP(str1, str2) strncmp(str1, str2, sizeof(str2) - 1)

static FILE *img_fp = NULL;

static void *cs_file_stream_proc(void *pParm)
{
    prctl(PR_SET_NAME, __func__);

    int a_rc                      = 0;
    int v_rc                      = 0;
    int rc                        = 0;
    iv_cm_aenc_pack_s aenc_packet = {0};
    iv_cm_venc_pack_s venc_packet = {0};
    iv_cs_info_s *p_cs_handle     = &sg_cs_info_handle;

    pthread_detach(pthread_self());
    printf("%s thread begin!\n", __func__);

    p_cs_handle->stream_thread.end = 0;
    while (p_cs_handle->stream_thread.start) {
        if (DEVICE_ONLINE_STATUE != sys_get_status()) {
            usleep(200 * 1000);
            continue;
        }

        // 遍历已初始化的通道进行推流
        for (int chl_index = 0; chl_index < CS_CH_NUM; chl_index++) {
            cs_enc_info *p_cs_enc_handle = &sg_cs_info_handle.chl_enc_info[chl_index];

            if (!p_cs_enc_handle->running) {
                usleep(2000);
                continue;
            }

            if (p_cs_enc_handle->handle) {
                a_rc = qcloud_get_audio_from_file(p_cs_enc_handle->handle, &aenc_packet);
                v_rc = qcloud_get_video_from_file(p_cs_enc_handle->handle, &venc_packet);
                // 音频和视频都未获取到
                if ((a_rc < 0) && (v_rc < 0)) {
                    usleep(2000);
                    continue;
                }

                // 获取到音频
                if (a_rc == 0) {
                    rc = iv_cs_push_stream(chl_index, IV_CM_STREAM_TYPE_AUDIO, &aenc_packet);
                    if (rc) {
                        printf("send cs audio stream failed %d\n", rc);
                    }
                }

                // 获取到视频
                if (v_rc == 0) {
                    rc = iv_cs_push_stream(chl_index, IV_CM_STREAM_TYPE_VIDEO, &venc_packet);
                    if (rc) {
                        printf("send cs video stream failed %d\n", rc);
                    }
                }
            }
        }
        usleep(1000);
    }
    p_cs_handle->stream_thread.end = 1;
    printf("%s thread end!\n", __func__);
}

static int cloudStorage_image(iv_cs_chn_e channel, int event_id, uint8_t **pic, int32_t *size);
static int cloudStorage_image_result(iv_cs_chn_e channel, uint8_t **pic, int32_t err_code);

static void *cs_event_proc(void *param)
{
    int32_t chl             = 0;
    int32_t count_down_ms   = 0;
    int32_t event_sleep     = 0;
    int32_t event_id        = 0;
    int32_t event_duration  = 0;
    int32_t event_pre_time  = 0;
    uint32_t event_end_time = 0;
    FILE *fpr_event         = NULL;
    char *p_fgets           = NULL;
    char event_script_buf[256];
    char event_action_buf[256];
    iv_cs_info_s *p_cs_handle = (iv_cs_info_s *)param;
    int cnt                   = 0;

    sleep(2);

    pthread_detach(pthread_self());

    printf("%sthread begin!\n", __func__);
    fpr_event = fopen(EVENT_TSET_FILE, "r");
    if (fpr_event == NULL) {
        printf("can not open %s\n", EVENT_TSET_FILE);
        return NULL;
    }
    p_cs_handle->event_thread.end = 0;

    memset(event_script_buf, 0, sizeof(event_script_buf));
    memset(event_action_buf, 0, sizeof(event_action_buf));

    while (p_cs_handle->event_thread.start) {
        iv_cs_balance_info_s cs_balance = {0};

        // int rc = iv_cs_get_balance_info(, &cs_balance, 0);
        // if (rc) {
        //     printf("get cs balance info failed!\n");
        //     sleep(2);
        //     continue;
        // }

        // if (0 == cs_balance.cs_switch) {
        //     if (cnt > 50) {
        //         printf("cs balance is invalid!\n");
        //         cnt = 0;
        //     } else {
        //         cnt++;
        //     }
        //     sleep(1);
        //     continue;
        // }

        memset(event_script_buf, 0, sizeof(event_script_buf));
        p_fgets = fgets(event_script_buf, sizeof(event_script_buf) - 1, fpr_event);
        if (strlen(event_script_buf) == 0 || p_fgets == NULL) {
            break;
        }

        if (event_script_buf[0] == '#' || event_script_buf[0] == '\r' ||
            event_script_buf[0] == '\n') {
            continue;
        }

        if (STR_N_CMP(event_script_buf, "end") == 0) {
            printf("event test stop\n");
            break;
        } else if (STR_N_CMP(event_script_buf, "reset") == 0) {
            fseek(fpr_event, 0, SEEK_SET);
            printf("event test reset\n");
        } else if (STR_N_CMP(event_script_buf, "start") == 0) {
            sscanf(event_script_buf, "%[^,],%d,%d", event_action_buf, &event_id, &chl);
            printf("chl:%d event(%d) start\n", chl, event_id);
            iv_cs_event_start(chl, event_id);
        } else if (STR_N_CMP(event_script_buf, "stop") == 0) {
            sscanf(event_script_buf, "%[^,],%d,%d", event_action_buf, &event_id, &chl);
            printf("chl:%d event(%d) stop\n", chl, event_id);
            iv_cs_event_stop(chl, event_id);
        } else if (STR_N_CMP(event_script_buf, "event") == 0) {
            sscanf(event_script_buf, "%[^,],%d,%d", event_action_buf, &event_id, &event_duration);
            printf("event id: %d, duration: %d\n", event_id, event_duration);
            count_down_ms = event_duration * 1000;

            iv_cs_event_start(chl, event_id);
            while (count_down_ms) {
                count_down_ms -= 100;
                usleep(100 * 1000);
            }
            iv_cs_event_stop(chl, event_id);
        } else if (STR_N_CMP(event_script_buf, "sleep") == 0) {
            sscanf(event_script_buf, "%[^,],%d", event_action_buf, &event_sleep);
            printf("event sleep %d second\n", event_sleep);
            sleep(event_sleep);
        } else if (STR_N_CMP(event_script_buf, "pre_event") == 0) {
            //事件指定事件触发开始结束
            sscanf(event_script_buf, "%[^,],%d,%d,%d,%d", event_action_buf, &event_id, &event_duration, &event_pre_time,
                   &chl);
            printf("event id: %d, duration: %d, per_time: %d\n", event_id, event_duration,
                   event_pre_time);
            count_down_ms = (event_duration + event_pre_time) * 1000;

            struct timeval tv;
            memset(&tv, 0, sizeof(tv));
            gettimeofday(&tv, NULL);

            sleep(event_pre_time);
            iv_cs_event_start_ext(chl, event_id, tv.tv_sec, tv.tv_sec);

            while (count_down_ms) {
                count_down_ms -= 100;
                usleep(100 * 1000);
            }
            event_end_time = tv.tv_sec + event_duration + event_pre_time;
            iv_cs_event_stop_ext(chl, event_id, event_end_time, event_end_time);
        } else {
            // error
            printf("unknown script %s\n", event_script_buf);
        }
        usleep(40 * 1000);
    }

    fclose(fpr_event);
    p_cs_handle->event_thread.end = 1;
    printf("%s thread end!\n", __func__);

    return 0;
}
static int qcloud_cs_file_stream_exit(void)
{
    iv_cs_info_s *p_cs_handle = &sg_cs_info_handle;

    if (p_cs_handle->stream_thread.start) {
        p_cs_handle->stream_thread.start = 0;
        while (!p_cs_handle->stream_thread.end) {
            usleep(100 * 1000);
        }
    }

    memset(&p_cs_handle->stream_thread, 0, sizeof(iv_cs_thread_s));
    Log_d("%s success!\n", __func__);
    return 0;
}

static int qcloud_cs_file_stream_init(void)
{
    iv_cs_info_s *p_cs_handle = &sg_cs_info_handle;

    p_cs_handle->stream_thread.start = 1;
    p_cs_handle->stream_thread.end   = 1;
    if (pthread_create(&p_cs_handle->stream_thread.pid, NULL, cs_file_stream_proc, NULL) < 0) {
        p_cs_handle->stream_thread.start = 0;
        Log_e("failed to create the cs_file_stream_proc pthread.\n");
        goto exit;
    }

    Log_d("%s success!\n", __func__);
    return 0;

exit:
    qcloud_cs_file_stream_exit();
    return -1;
}

static int qcloud_cs_event_stop(void)
{
    iv_cs_info_s *p_cs_handle = &sg_cs_info_handle;

    if (p_cs_handle->stream_thread.start) {
        p_cs_handle->stream_thread.start = 0;
        while (!p_cs_handle->stream_thread.end) {
            usleep(100 * 1000);
        }
    }

    memset(&p_cs_handle->stream_thread, 0, sizeof(iv_cs_thread_s));

    return 0;
}

static int qcloud_cs_event_init(void)
{
    iv_cs_info_s *p_cs_handle = &sg_cs_info_handle;

    p_cs_handle->event_thread.start = 1;
    p_cs_handle->event_thread.end   = 1;
    if (pthread_create(&p_cs_handle->event_thread.pid, NULL, cs_event_proc, p_cs_handle) < 0) {
        p_cs_handle->event_thread.start = 0;
        Log_e("failed to create the cs_event_proc pthread.\n");
        goto exit;
    }

    Log_d("%s success!\n", __func__);
    return 0;

exit:
    qcloud_cs_event_stop();
    return -1;
}

static int qcloud_cs_stream_stop(iv_cs_chn_e channel)
{
    uint8_t chl_index            = channel;
    cs_enc_info *p_cs_enc_handle = &sg_cs_info_handle.chl_enc_info[chl_index];

    p_cs_enc_handle->running = 0;

    qcloud_file_stream_exit(p_cs_enc_handle->handle);
    p_cs_enc_handle->handle = NULL;

    return 0;
}

static int qcloud_cs_stream_start(iv_cs_chn_e channel)
{
    uint8_t chl_index            = channel;
    cs_enc_info *p_cs_enc_handle = &sg_cs_info_handle.chl_enc_info[chl_index];

    if (p_cs_enc_handle->handle) {
        Log_e("%s have initial!\n", __func__);
        return -1;
    }

    p_cs_enc_handle->handle = qcloud_file_stream_init(chl_index, CS_FLIE_STREAM_ID, 1);
    if (!p_cs_enc_handle->handle) {
        Log_e("%s file stream initial failed!\n", __func__);
        return -1;
    }
    p_cs_enc_handle->running = 1;
    Log_d("%s success!\n", __func__);
    return 0;

exit:
    qcloud_cs_stream_stop(channel);
    return -1;
}

static int cloudStorage_event_result(iv_cs_chn_e channel, iv_cs_event_result_info *pst_result_info)
{
    printf("channel:%d cloud storage event[%d] result:%d\n", channel, pst_result_info->event_id,
           pst_result_info->result_code);
    return 0;
}

static int cloudStorage_start(iv_cs_chn_e channel)
{
    printf("channel:%d cloud storage start\n", channel);

    int rc          = 0;
    int64_t time    = 0;
    time_t time_tmp = 0;
    char buf[256]   = {0};

    rc = iv_sys_get_time(&time);
    if (QCLOUD_RET_SUCCESS == rc) {
        utc_to_localtime_ms(time, buf, sizeof(buf));
        printf("sys get system time is [%s]\n", buf);
    } else {
        printf("sys get system time failed!\n");
    }
    qcloud_cs_stream_start(channel);
    return 0;
}

static int cloudStorage_upload_state(iv_cs_upload_info_s *info)
{
    int i = 0;
    printf("cloud storage upload state:\n");
    for (i = 0; i < info->num; i++) {
        printf("state %d, size %d / %d, frame %d, %d, pts %" PRIu64 ", %" PRIu64 ", utc %" PRIu64
               ", %" PRIu64 "\n",
               info->slice_info[i].state, info->slice_info[i].upload_size,
               info->slice_info[i].total_size, info->slice_info[i].frame_seq_a,
               info->slice_info[i].frame_seq_b, info->slice_info[i].pts_ms_a,
               info->slice_info[i].pts_ms_b, info->slice_info[i].utc_sec_a,
               info->slice_info[i].utc_sec_b);
    }
    printf("\n");
    return 0;
}

static int cloudStorage_notify_msg(iv_cs_chn_e channel, iv_cs_notify_msg_type_e notify_msg_type,
                                   iv_cs_notify_msg_data *pst_notify_data)
{
    printf("channel:%d cloud storage notify msg type:%d\n", channel, notify_msg_type);

    switch (notify_msg_type) {
        case IV_CS_AV_UPLOAD_STATE_MSG:
            cloudStorage_upload_state(pst_notify_data->av_result_info);
        default:
            break;
    }

    return 0;
}

static int cloudStorage_image(iv_cs_chn_e channel, int event_id, uint8_t **pic, int32_t *size)
{
    char img_path[64];
    int file_size    = 0;
    int ret          = 0;
    uint8_t *img_buf = NULL;

    if (event_id > 32 || event_id < 1) {
        printf("event_id(%d) invalid\n", event_id);
        *pic  = NULL;
        *size = 0;
        return 0;
    }

    sprintf(img_path, "%s%02d.jpg", EVENT_PIC_PATH, event_id);
    img_fp = fopen(img_path, "rb");
    if (img_fp == NULL) {
        printf("can not open %s\n", img_path);
        *pic  = NULL;
        *size = 0;
        return 0;
    }

    fseek(img_fp, 0, SEEK_END);
    file_size = ftell(img_fp);
    fseek(img_fp, 0, SEEK_SET);

    if (file_size == 0) {
        printf("file %s size is zero!\n", img_path);
        *pic  = NULL;
        *size = 0;
        goto end;
    }

    img_buf = (uint8_t *)malloc(file_size);
    if (img_buf == NULL) {
        printf("malloc img_buf size %d error\n", file_size);
        *pic  = NULL;
        *size = 0;
        goto end;
    }

    ret = fread(img_buf, 1, file_size, img_fp);
    if (ret == file_size) {
        *pic  = img_buf;
        *size = file_size;
    } else {
        printf("read file %s error\n", img_path);
        free(img_buf);
        *pic  = NULL;
        *size = 0;
        goto end;
    }

    printf("channel:%d cloud storage get event image %p\n", channel, *pic);
end:
    fclose(img_fp);
    return 0;
}

static int cloudStorage_image_result(iv_cs_chn_e channel, uint8_t **pic, int32_t err_code)
{
    printf("cloud storage releast event image %p\n", *pic);

    if (*pic) {
        free(*pic);
    }

    return 0;
}

static int cloudStorage_stop(iv_cs_chn_e channel)
{
    printf("channel:%d cloud storage stop\n", channel);
    qcloud_cs_stream_stop(channel);
    return 0;
}

void cloudStorage_ai_service_notify(iv_cs_chn_e channel, unsigned int u32AiServerType, unsigned long long u64UtcExpire)
{
    printf("channel:%d u32AiServerType: %d, u64UtcExpire: %lld\n", channel, u32AiServerType, u64UtcExpire);
}

int cloud_storage_init(void)
{
    int err_code = 0;

    int chl_id                            = 0;
    iv_cs_init_parm_s stCsInitParm        = {0};
    iv_cs_channel_params_s stChnParams[CS_CH_NUM] = {0};
    memset(&stCsInitParm, 0, sizeof(iv_cs_init_parm_s));
    memset(&stChnParams, 0, sizeof(iv_cs_channel_params_s));

    stCsInitParm.channel_num = 2;

    for (int i = 0; i < stCsInitParm.channel_num; i++) {
        chl_id = i + 1;
        if (qcloud_get_file_stream_format(chl_id, CS_FLIE_STREAM_ID, &stChnParams[i].av_fmt)) {
            Log_e("get file stream format failed:%d", i);
            return -1;
        }
        if (stChnParams[i].av_fmt.eAudioType == IV_CM_AENC_TYPE_AAC) {
            stChnParams[i].av_fmt.u32AudioCodecOption = IV_CM_AAC_TYPE_LC;
        }

        stChnParams[i].channel_id    = chl_id;
        stChnParams[i].u32MaxGopSize = 512 * 1024;
        stChnParams[i].cs_fmt        = IV_CS_FORMAT_TS;
    }

    err_code = qcloud_cs_event_init();
    if (err_code < 0) {
        Log_e("qcloud_cs_stream_init failed:%d", err_code);
        return err_code;
    }

    stCsInitParm.func_cb.iv_cs_push_stream_start_cb     = cloudStorage_start;
    stCsInitParm.func_cb.iv_cs_push_stream_stop_cb      = cloudStorage_stop;
    stCsInitParm.func_cb.iv_cs_event_capture_picture_cb = cloudStorage_image;
    stCsInitParm.func_cb.iv_cs_event_picture_result_cb  = cloudStorage_image_result;
    stCsInitParm.func_cb.iv_cs_event_report_result_cb   = cloudStorage_event_result;
    stCsInitParm.func_cb.iv_cs_notify_cb                = cloudStorage_notify_msg;
    stCsInitParm.func_cb.iv_cs_ai_service_notify_cb     = cloudStorage_ai_service_notify;
    stCsInitParm.ch_params   = stChnParams;
    err_code = iv_cs_init(&stCsInitParm);
    if (err_code < 0) {
        Log_e("iv_cs_init error:%d", err_code);
        return err_code;
    }

    err_code = qcloud_cs_file_stream_init();
    if (err_code < 0) {
        Log_e("qcloud_cs_file_stream_init failed:%d", err_code);
        return err_code;
    }

    return err_code;
}

int cloud_storage_exit(void)
{
    qcloud_cs_file_stream_exit();
    qcloud_cs_event_stop();
    return iv_cs_exit();
}

#ifdef __cplusplus
}
#endif
