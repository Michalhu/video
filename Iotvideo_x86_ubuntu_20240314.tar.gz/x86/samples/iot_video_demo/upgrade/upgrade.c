/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @file    upgrade.c
 * @brief   Description upgrade function
 * @version v1.0.0
 *
 *****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif /* __cpluscplus */

#include "upgrade.h"

#include "iv_err.h"
#include "iv_ota.h"
#include "qcloud_iot_export.h"
#include "qcloud_iot_import.h"

#define OTA_FIRMWARE_PATH    "/tmp"
#define OTA_FIRMWARE_VERSION "1.0.0"

void upgrade_firmware_update(char *pFirmwarePath, uint64_t u32FirmwareLen)
{
    FILE *fpFirmware = NULL;
    Log_d("firmware file:%s,len:%d", pFirmwarePath, u32FirmwareLen);

    fpFirmware = fopen(pFirmwarePath, "rb");
    if (!fpFirmware) {
        Log_e("open firmware file:%s failed", pFirmwarePath);
        iv_ota_update_progress(IV_OTA_PROGRESS_TYPE_FAIL, IV_OTA_FAIL_TYPE_OPEN_FILE);
        upgrade_exit();
        return;
    }
    fseek(fpFirmware, 0, SEEK_END);
    if (u32FirmwareLen != ftell(fpFirmware)) {
        Log_e("%s real size is wrong, u32FirmwareLen:%lld, fileLen:%ld.\n", pFirmwarePath, u32FirmwareLen,
              ftell(fpFirmware));
        iv_ota_update_progress(IV_OTA_PROGRESS_TYPE_FAIL, IV_OTA_FAIL_TYPE_WRONG_SIZE);
        upgrade_exit();
        return;
    }
    fclose(fpFirmware);
    fpFirmware = NULL;

    iv_ota_update_progress(IV_OTA_PROGRESS_TYPE_WRITE_FLASH, 0);
    HAL_SleepMs(1000);
    iv_ota_update_progress(IV_OTA_PROGRESS_TYPE_SUCCESS, 0);
    upgrade_exit();
    return;
}

static int _ota_prepare() {
    return 0; // return 0 means prepare OK, ota will continue
}

/*
\brief: 	upgrade init
\attention:	N/A
\param:		N/A
\return:	void
*/
int upgrade_init(void)
{
    int eErrCode = 0;
    iv_ota_init_parm_s stUpgradeInitParm;
    memset(&stUpgradeInitParm, 0, sizeof(iv_ota_init_parm_s));
    stUpgradeInitParm.iv_ota_firmware_update_cb = upgrade_firmware_update;
    stUpgradeInitParm.iv_ota_prepare_cb = _ota_prepare;
    strncpy(stUpgradeInitParm.firmware_path, OTA_FIRMWARE_PATH, sizeof(stUpgradeInitParm.firmware_path));
    strncpy(stUpgradeInitParm.firmware_version, OTA_FIRMWARE_VERSION, sizeof(stUpgradeInitParm.firmware_version));
    eErrCode = iv_ota_init(&stUpgradeInitParm);
    if (eErrCode < 0) {
        Log_e("iv_ad_ap_init error:%d", eErrCode);
    }

    return 0;
}

/*
\brief: 	upgrade exit
\attention:	N/A
\param:		N/A
\return:	void
*/
int upgrade_exit(void)
{
    return iv_ota_exit();
}

#ifdef __cplusplus
}
#endif /* __cpluscplus */
