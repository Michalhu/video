#include "iv_usrex.h"
#include "iv_def.h"
/*-----------------data config start  -------------------*/ 

#define TOTAL_WR_PROPERTY_COUNT 2

static sDataPoint    sg_WR_DataTemplate[TOTAL_WR_PROPERTY_COUNT];

ivm_extend_param_t    g_ivm_objs;

static void _ivm_init_data_template(void)
{
    sg_WR_DataTemplate[0].data_property.data = &g_ivm_objs.ProWritable.m_record_enable;
    sg_WR_DataTemplate[0].data_property.key  = "record_enable";
    sg_WR_DataTemplate[0].data_property.type = TYPE_TEMPLATE_BOOL;
    sg_WR_DataTemplate[0].state = eNOCHANGE;

    memset(&g_ivm_objs.ProWritable.m_presetList, 0, sizeof(g_ivm_objs.ProWritable.m_presetList));
    sg_WR_DataTemplate[1].data_property.data = &g_ivm_objs.ProWritable.m_presetList;
    sg_WR_DataTemplate[1].data_property.array_info.array_size = MAX_ARRAY_JSON_STR_LEN;
    sg_WR_DataTemplate[1].data_property.array_info.array_type = TYPE_TEMPLATE_JOBJECT;
    sg_WR_DataTemplate[1].data_property.key  = "presetList";
    sg_WR_DataTemplate[1].data_property.type = TYPE_TEMPLATE_ARRAY;
    sg_WR_DataTemplate[1].state = eNOCHANGE;

};

extern int ivm_init_ProWritable(void *obj, int num, char *name, ivm_callback_ProWritable cb, char close_sync);

#define ivm_doi_init_ProWritable(data, flag) ivm_init_ProWritable(sg_WR_DataTemplate, TOTAL_WR_PROPERTY_COUNT, #data, (ivm_callback_ProWritable)iv_usrcb_ProWritable_##data, flag)


int ivm_env_init(void)
{
    memset((void *) &g_ivm_objs, 0, sizeof(ivm_extend_param_t));
    _ivm_init_data_template();

    ivm_doi_init_ProWritable(record_enable, 0);
    ivm_doi_init_ProWritable(presetList, 0);



    return 0;
}
