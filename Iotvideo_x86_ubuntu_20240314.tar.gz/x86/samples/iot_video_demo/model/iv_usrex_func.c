/*
    用户实现本文件中定义的各个功能回调函数，即实现了具体的业务功能.
    回调函数实现注意事项:

    1.在回调函数中，不能做阻塞式操作，禁止在回调函数中做耗时的操作;
    2.在非回调函数中访问物模型对象资源，应该使用ivm_lock()/ivm_unlock()加锁和解锁;
    3.在回调函数处理中，不要进行加锁/解锁操作。（因为通讯线程已经加锁了）
*/

#include <assert.h>
#include "iv_usrex.h"
#include "iv_cm.h"
#include "lite-utils.h"

#define MAX_PRESET_LIST_SIZE    16

typedef struct _presetList {
    int enabled;
    char name[128];
    char url[256];
} presetList_elem_t;

static presetList_elem_t sg_preset_list[MAX_PRESET_LIST_SIZE];
static int sg_preset_size = 0;

int iv_usrcb_ProWritable_record_enable(const TYPE_DEF_TEMPLATE_BOOL *record_enable)
{
    // User implementation code
    // 注意: 回调函数中,不能做阻塞式操作,不得做耗时的操作。会导致核心通讯线程阻塞!!!
    Log_d("Get record_enable %d", *record_enable);
    return 0;
}

static int _parse_presetList_obj(const char *json_str, size_t str_len, void *obj, size_t obj_len) 
{
    int ret = 0;
    if (obj_len != sizeof(presetList_elem_t)) {
        Log_e("obj_len %zu != %zu", obj_len, sizeof(presetList_elem_t));

        return QCLOUD_ERR_FAILURE;
    }
    presetList_elem_t *p_ple = (presetList_elem_t *)obj;

    char  temp[1024];
    char *p = NULL;
    memcpy(temp, json_str, str_len);
    temp[str_len] = '\0';

    p = LITE_json_value_of("enabled", temp);
    if (NULL == p) {
        return QCLOUD_ERR_FAILURE;
    }
    ret = LITE_get_int32(&(p_ple->enabled), p);
    HAL_Free(p);
    if (ret < 0)
        return ret;

    p = LITE_json_value_of("name", temp);
    if (NULL == p)
        return QCLOUD_ERR_FAILURE;
    ret = LITE_get_string((p_ple->name), p, sizeof(p_ple->name));
    HAL_Free(p);

    p = LITE_json_value_of("picURL", temp);
    if (NULL == p)
        return QCLOUD_ERR_FAILURE;
    ret = LITE_get_string((p_ple->url), p, sizeof(p_ple->url));
    HAL_Free(p);

    return ret;
}

int iv_usrcb_ProWritable_presetList(const TYPE_DEF_TEMPLATE_ARRAY *presetList)
{
    //User implementation code
    //注意: 回调函数中,不能做阻塞式操作,不得做耗时的操作。会导致核心通讯线程阻塞!!!
    Log_d("Get presetList %s", presetList);
    int res = LITE_dt_parse_obj_array(sg_preset_list, MAX_PRESET_LIST_SIZE * sizeof(presetList_elem_t),
                                      sizeof(presetList_elem_t), presetList, _parse_presetList_obj);
    if (res > 0) {
        sg_preset_size = res;
        Log_d("size: %d", sg_preset_size);
        for (int i = 0; i < res; i++) {
            Log_d("Info %d - enabled %d name %s url %s", i, sg_preset_list[i].enabled, sg_preset_list[i].name, sg_preset_list[i].url);
        }
    }

    return 0;
}

