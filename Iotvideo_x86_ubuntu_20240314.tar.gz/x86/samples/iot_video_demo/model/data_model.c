/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 * @file    datamodel.c
 * @brief   Description data model function
 * @version v1.0.0
 *
 *****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif /* __cpluscplus */

#include <stdio.h>

#include "qcloud_iot_export_log.h"
#include "iv_def.h"
#include "iv_dm.h"

// only for demo test
// please check your data model configs
#define TEST_USER_DEFINE_PROPERTY

#ifdef TEST_USER_DEFINE_PROPERTY
#include "iv_usrex.h"
#endif

static int ivm_property_report_result(void *param, iv_dm_report_result_e code)
{
    Log_i("param %s, code %d", (char *)param, code);
    return 0;
}

/**
 * @brief data model synchronize
 *
 */
void dm_sync(void)
{
    Log_d("data model sync called");

#ifdef TEST_USER_DEFINE_PROPERTY
    int ret = iv_dm_property_sync(5000);
    if (ret) {
        Log_e("data model sync failed %d", ret);
    } else {
        Log_d("data model sync value record_enable: %d",
              g_ivm_objs.ProWritable.m_record_enable);
    }
#endif
}

/*
\brief: 	data model module init
\attention:	N/A
\param:		N/A
\return:	void
*/
int dm_init(void)
{
    int rc = 0;
    iv_dm_init_parm_s stInitParm;
#ifdef TEST_USER_DEFINE_PROPERTY
    stInitParm.iv_dm_env_init_cb = ivm_env_init;
#else
    stInitParm.iv_dm_env_init_cb = NULL;
#endif
    rc                           = iv_dm_init(&stInitParm);
    if (rc < 0) {
        Log_e("model init failed!");
        return rc;
    }

#ifdef TEST_USER_DEFINE_PROPERTY
    ivm_ProWritable_setInt(record_enable, 0);
#endif
    return rc;
}

/*
\brief: 	data model module init
\attention:	N/A
\param:		N/A
\return:	void
*/
void dm_exit(void)
{
    iv_dm_exit();
}

#ifdef __cplusplus
}
#endif /* __cpluscplus */
