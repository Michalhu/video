#include <signal.h>

#include "ini_config.h"
#include "iv_config.h"

#ifdef AVT_P2P_ENABLED
#include "av_talk.h"
#endif

#ifdef CLOUD_STORAGE_ENABLED
#include "cloud_storage.h"
#endif
#include "data_model.h"
#include "iv_def.h"
#include "iv_system.h"
#ifdef LOCAL_RECORD_ENABLED
#include "record.h"
#endif
#ifdef LOW_POWER_ENABLED
#include "iv_keep_alive.h"
#endif
#include "lite-utils.h"
#include "qcloud_iot_export.h"
#include "qcloud_iot_import.h"

#ifdef LOW_POWER_ENABLED
#include "iv_keep_alive.h"
#endif

#if defined(CLOUD_AI_ENABLED) && !defined(CLOUD_AI_COS_ENABLED)
#include "cloud_ai.h"
#endif

#ifdef OTA_COMM_ENABLED
#include "upgrade.h"
#endif

extern const char *params_device_info_file;
extern int params_p2p_log_level;
extern const char *params_p2p_log_path;
extern int params_p2p_protocol;
extern int params_p2p_sender_interval_ms;
extern const char *params_netif_name;
extern char params_proxy_addr[32];
extern int params_p2p_prioriry;
static char *sg_config_file = "./demo_media/demo_media_cfg.ini";
static char *usage = "./iot_video_demo -c [config_file] -d [device_info_file] -p [p2p log level] -i [netif_name] -a [proxy_addr] -s [p2p sender interval] -t";

static int _parse_arguments(int argc, char** argv)
{
    char* optstring = "c:d:p:i:a:s:x:t";
    int   opt;

    while ((opt = getopt(argc, argv, optstring)) != -1) {
        switch (opt) {
        case 'c':
            sg_config_file = optarg;
            break;
        case 'd':
            params_device_info_file = optarg;
            break;
        case 'p':
            params_p2p_log_level = atoi(optarg);
            break;
        case 'i':
            params_netif_name = optarg;
			break;
        case 'a':
            strncpy(params_proxy_addr, optarg, sizeof(params_proxy_addr)-1);
            break;
        case 's':
            params_p2p_sender_interval_ms = atoi(optarg);
            break;
        case 't':
            params_p2p_protocol = 1; // P2P TCP
            break;
        case 'x':
            params_p2p_prioriry = atoi(optarg);
            break;
        default:
            printf("usage:\n%s\n", usage);
            return -1;
        }
    }

    return 0;
}

static uint32_t process_exit = 0;
void main_exit(int sig)
{
    printf("vIpcExit by signal:%d\n", sig);
    process_exit = 1;
}

int main(int argc, char **argv)
{
    process_exit = 0;
    signal(SIGTERM, main_exit);
    signal(SIGINT, main_exit);

    _parse_arguments(argc, argv);

    if (iv_config_init(sg_config_file)) {
        return -1;
    }

    sys_init();

    dm_init();

#ifdef AVT_P2P_ENABLED
    av_talk_init();
#endif

#ifdef LOCAL_RECORD_ENABLED
    record_init();
#endif

    sleep(1);
    while (DEVICE_ONLINE_STATUE != sys_get_status()) {
        sleep(1);
    }

#ifdef OTA_COMM_ENABLED
    upgrade_init();
#endif

    if (DEVICE_ONLINE_STATUE == sys_get_status()) {
#ifdef CLOUD_STORAGE_ENABLED
        cloud_storage_init();  //云存必须上线后才能初始化成功;
#endif

#ifdef LOW_POWER_ENABLED
        keep_alive_info_update();
#endif
    }

#if defined(CLOUD_AI_ENABLED) && !defined(CLOUD_AI_COS_ENABLED)
    cloud_ai_init();
#endif

    unsigned int count = 0;
    while (!process_exit) {
        count++;
        sleep(1);
    }

#ifdef OTA_COMM_ENABLED
    upgrade_exit();
#endif

#ifdef CLOUD_STORAGE_ENABLED
    cloud_storage_exit();
#endif

#if defined(CLOUD_AI_ENABLED) && !defined(CLOUD_AI_COS_ENABLED)
    cloud_ai_exit();
#endif

#ifdef AVT_P2P_ENABLED
    av_talk_exit();
#endif

#ifdef LOCAL_RECORD_ENABLED
    record_exit();
#endif

    dm_exit();

    sys_exit();

    iv_config_deinit();

#ifdef LOW_POWER_ENABLED
    // 模拟设备保活
    // simulation_device_low_power_keep_alive();
#endif
    return 0;
}
