/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 * @file    iv_system.h
 * @brief   Description system function
 * @version v1.0.0
 *
 *****************************************************************************/

#ifndef __IV_SYSTEM_H__
#define __IV_SYSTEM_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cpluscplus */

#define MAX_CHANNEL_NUM 3

#define DEVICE_CONNECTING_STATUE 0
#define DEVICE_ONLINE_STATUE     1
#define DEVICE_OFFLINE_STATUE    2
#define MAX_SIZE_OF_DEV_SECRET   (64)
#define SYS_NULL_OF_DEV_SERCERT  "YOUR_DEVICE_SERCERT"

int sys_init(void);
int sys_exit(void);
char sys_get_status(void);

#ifdef __cplusplus
}
#endif /* __cpluscplus */

#endif /* __IV_SYSTEM_H__ */
