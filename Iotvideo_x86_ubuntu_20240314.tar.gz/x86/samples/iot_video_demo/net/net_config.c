/*****************************************************************************
 * Tencent is pleased to support the open source community by making IoT Video available.
 * Copyright (C) 2020 THL A29 Limited, a Tencent company. All rights reserved.
 * Licensed under the MIT License (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/MIT
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 *is distributed on an "AS IS" basis, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 *or implied. See the License for the specific language governing permissions and limitations under
 *the License.
 *
 * @file    net_config.c
 * @brief   Description add device network config
 * @version v1.0.0
 *
 *****************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include "net_config.h"

#include <stdint.h>
#include <string.h>

#include "iv_ad.h"
#include "qcloud_iot_export.h"

static void ad_recv_ap_config_info(char *data, uint32_t length)
{
    Log_i("recv size:%d data:%s", length, data);
}

int net_config_init(bool is_ap_mode)
{
    int eErrCode = 0;

    /* ap配网和有线配网不能同时使用 */
    if (is_ap_mode) {
        iv_ad_ap_init_parm_s stADInitParm;
        stADInitParm.iv_ad_ap_recv_config_info_cb = ad_recv_ap_config_info;
        eErrCode                                  = iv_ad_ap_init(&stADInitParm);
        if (eErrCode < 0) {
            Log_e("iv_ad_ap_init error:%d", eErrCode);
        }
    } else {
        iv_ad_wired_init("239.0.0.255", 7838);
    }

    return 0;
}

int net_config_exit(bool is_ap_mode)
{
    if (is_ap_mode) {
        iv_ad_ap_exit();
    } else {
        iv_ad_wired_exit();
    }

    return 0;
}

#ifdef __cplusplus
}
#endif /* __cplusplus */
